# Registro BR

## Your Domain

### Configuração DNS Registro BR

* Servidor 1
    * 01-your.apontamento.com.br

* Servidor 2
    * 02-your.apontamento.com.br

* DS 1
    * Keytag 43921
    * Digest 01-yourkey.digest.generate

* DS 2
    * Keytag 59372
    * Digest 01-yourkey.digest.generate

  ![Screenshot](img/registrobr/yourdomain_zona_dns.jpg)
