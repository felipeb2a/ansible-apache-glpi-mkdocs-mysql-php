# Procedimentos Zabbix

## Documentação Zabbix

* Para mais informações leia a Documentação [Click aqui](https://www.zabbix.com/documentation/6.0/pt/manual/introduction)

## Links UUID

* Link para captura do UUID do HostVmWare [Click aqui](https://172.16.16.52/mob/?moid=ha-host&doPath=hardware.systemInfo)
  * Altere para o IP do servidor desejado.

* Link para captura do UUID da VM [Click aqui](https://172.16.16.52/mob/?moid=ha-folder-vm)
  * Altere para o IP do servidor desejado.

## Instalação Windows

* Acessar a pasta onde se encontra o software `\\SRV-FILESERVER\Infraestrutura\ZABBIX`;

  ![Screenshot](img/procedimento-zabbix/instalacao/arquivos-de-instalacao.jpg)

* Copie os arquivos em destaque para o computador onde será instalado;

  ![Screenshot](img/procedimento-zabbix/instalacao/arquivos-de-instalacao-02.jpg)

* Execute o instalador do zabbix;

  ![Screenshot](img/procedimento-zabbix/instalacao/instalacao-01.jpg)

* Marque as opções como na imagem abaixo e click em next;

  ![Screenshot](img/procedimento-zabbix/instalacao/instalacao-02.jpg)
  

* Adicione as informações como na imagem e click em next;

  ![Screenshot](img/procedimento-zabbix/instalacao/instalacao-03.jpg)
  

* Nessa janela vamos inserir nossa chave PSK;
* Abra o arquivo PSK001 e copie a chave;
* No instalador do zabbix insira as informações iguais a imagem abaixo.

  ![Screenshot](img/procedimento-zabbix/instalacao/instalacao-04.jpg)
  

* Click em Install;

  ![Screenshot](img/procedimento-zabbix/instalacao/instalacao-05.jpg)
  

* Click em sim;

  ![Screenshot](img/procedimento-zabbix/instalacao/instalacao-06.jpg)
  

* Click em finish;

  ![Screenshot](img/procedimento-zabbix/instalacao/instalacao-07.jpg)
  

* Edite o arquivo `zabbix_agentd.conf` que copiamos;

  ![Screenshot](img/procedimento-zabbix/instalacao/editar-conf-01.jpg)
  

* Na linha 17 edite o `Hostname` informando o IP da maquina atual que estamos configurando;
* Salve e feche o arquivo.

  ![Screenshot](img/procedimento-zabbix/instalacao/editar-conf-02.jpg)
  

* Vamos substituir o arquivo que editamos, acesse a pasta `C:\Program Files\Zabbix Agent`;
  ![Screenshot](img/procedimento-zabbix/instalacao/alterar-arqui-conf-01.jpg)
  

* Copie o arquivo editado para a pasta e substitua o antigo;
  ![Screenshot](img/procedimento-zabbix/instalacao/alterar-arqui-conf-02.jpg)
  

* Click em continuar;
  ![Screenshot](img/procedimento-zabbix/instalacao/alterar-arqui-conf-03.jpg)
  

* Abra os serviços do windows e encontre o serviço do zabbix;
* Click com o direito e em reiniciar o serviço.
* Se o serviço reiniciar o zabbix já vai estar instalado com sucesso!
  ![Screenshot](img/procedimento-zabbix/instalacao/reiniciar-servico-zabbix.jpg)

### Teste Zabbix

* Use zabbix-get to test:
    * Open CMD 
    * Browse C:\Program Files\Zabbix Agent
~~~ssh
zabbix_get.exe -s 127.0.0.1 -p 10050 -k "agent.version"
~~~
* Usando PSK

~~~ssh
zabbix_get.exe -s 127.0.0.1 --tls-connect "psk" --tls-psk-identity "PSK001" --tls-psk-file "C:\Program Files\Zabbix Agent\psk.key" -k agent.version
~~~

## Instalação Linux

* Acesse o servidor que deseja fazer a instalação;


### Debian e derivados

Site Oficial [Click Aqui](https://www.zabbix.com/download?zabbix=6.0&os_distribution=debian&os_version=9&components=agent&db=&ws=)

* Baixando o arquivo de instalação;

~~~ssh
sudo wget https://repo.zabbix.com/zabbix/6.0/debian/pool/main/z/zabbix-release/zabbix-release_6.0-3+debian11_all.deb
sudo dpkg -i zabbix-release_6.0-3+debian11_all.deb
sudo apt update
~~~

* Seguindo com a instalação;

~~~ssh
sudo apt install zabbix-agent zabbix-get
sudo ufw allow 10050/tcp
sudo ufw reload
sudo systemctl restart zabbix-agent
sudo systemctl enable zabbix-agent 
~~~

* Editando o arquivo de configuração do agente zabbix;

~~~ssh
sudo mv /etc/zabbix/zabbix_agentd.conf /etc/zabbix/zabbix_agentd.conf.bkp
sudo vi /etc/zabbix/zabbix_agentd.conf

adicione no arquivo as configurações abaixo

### Option: PidFile
PidFile=/var/run/zabbix/zabbix_agentd.pid

### Option: LogFile
LogFile=/var/log/zabbix/zabbix_agentd.log

### Option: LogFileSize
LogFileSize=0

### Option: Server
Server=192.168.0.55,srv-zabbix-server.yourdomain.com.br,127.0.0.1

### Option: ServerActive
#ServerActive=192.168.0.55

### Option: Hostname
Hostname=SRV-NAMEHOST

### Option: TLSConnect
TLSConnect=psk

### Option: TLSAccept
TLSAccept=psk

### Option: TLSPSKIdentity
TLSPSKIdentity=PSK001

### Option: TLSPSKFile
TLSPSKFile=/etc/zabbix/zabbix_agentd.psk

### Option: Include
Include=/etc/zabbix/zabbix_agentd.d/*.conf

####### USER-DEFINED MONITORED PARAMETERS #######

### Option: UserParameter Speed Test
# UserParameter=upload_interface01[*],cat /tmp/speedtest_interface01.txt | grep "Upload:" | cut -d " " -f2

# UserParameter=download_interface01[*],cat /tmp/speedtest_interface01.txt | grep "Download:" | cut -d " " -f2
~~~

* Adicionando o arquivo PSK;

~~~ssh
sudo vi /etc/zabbix/zabbix_agentd.psk

adicione no arquivo as configurações abaixo
YOURPSK
~~~

* Reiniciar serviço do zabbix-agent;

~~~ssh
sudo systemctl restart zabbix-agent
sudo systemctl status zabbix-agent
~~~

### RHEL e derivados

Site Oficial [Click Aqui](https://www.zabbix.com/download?zabbix=6.0&os_distribution=centos&os_version=9&components=server_frontend_agent&db=mysql&ws=apache)

* Baixando o arquivo de instalação;

~~~ssh
sudo vi /etc/yum.repos.d/epel.repo

Adicionar no arquivo
excludepkgs=zabbix*
~~~

* Salve e feche o arquivo.

  ![Screenshot](img/procedimento-zabbix/instalacao/linux/instalacao-rhel-01.jpg)

* Seguindo com a instalação;

~~~ssh
sudo rpm -Uvh https://repo.zabbix.com/zabbix/6.0/rhel/9/x86_64/zabbix-release-6.0-5.el9.noarch.rpm
sudo dnf clean all
sudo dnf install zabbix-agent zabbix-get
sudo firewall-cmd --permanent --add-port=10050/tcp
sudo firewall-cmd --reload
sudo systemctl restart zabbix-agent
sudo systemctl enable zabbix-agent 
~~~

  ![Screenshot](img/procedimento-zabbix/instalacao/linux/instalacao-rhel-02.jpg)

* Editando o arquivo de configuração do agente zabbix;

~~~ssh
sudo mv /etc/zabbix_agentd.conf /etc/zabbix_agentd.conf.bkp
sudo vi /etc/zabbix_agentd.conf

adicione no arquivo as configurações abaixo

### Option: PidFile
PidFile=/run/zabbix/zabbix_agentd.pid

### Option: LogFile
LogFile=/var/log/zabbix/zabbix_agentd.log

### Option: LogFileSize
LogFileSize=0

### Option: Server
Server=192.168.0.55,srv-zabbix-server.yourdomain.com.br,127.0.0.1

### Option: ServerActive
#ServerActive=192.168.0.55

### Option: Hostname
Hostname=VM-NAMEHOST 

### Option: TLSConnect
TLSConnect=psk

### Option: TLSAccept
TLSAccept=psk

### Option: TLSPSKIdentity
TLSPSKIdentity=PSK001

### Option: TLSPSKFile
TLSPSKFile=/etc/zabbix/zabbix_agentd.psk

### Option: Include
#Include=/etc/zabbix/zabbix_agentd.d/*.conf

####### USER-DEFINED MONITORED PARAMETERS #######

### Option: UserParameter Speed Test
# UserParameter=upload_interface01[*],cat /tmp/speedtest_interface01.txt | grep "Upload:" | cut -d " " -f2

# UserParameter=download_interface01[*],cat /tmp/speedtest_interface01.txt | grep "Download:" | cut -d " " -f2
~~~

* Adicionando o arquivo PSK;

~~~ssh
sudo vi /etc/zabbix/zabbix_agentd.psk

adicione no arquivo as configurações abaixo
YOURPSK
~~~

* Reiniciar serviço do zabbix-agent;

~~~ssh
sudo systemctl restart zabbix-agent
sudo systemctl status zabbix-agent
~~~
  
### Teste Zabbix

~~~ssh
sudo zabbix_get -s 127.0.0.1 --tls-connect "psk" --tls-psk-identity "PSK001" --tls-psk-file "/etc/zabbix/zabbix_agentd.psk" -k agent.version

sudo zabbix_get -s 127.0.0.1 --tls-connect "psk" --tls-psk-identity "PSK001" --tls-psk-file "/etc/zabbix/zabbix_agentd.psk" -k "download"

sudo zabbix_get -s 127.0.0.1 --tls-connect "psk" --tls-psk-identity "PSK001" --tls-psk-file "/etc/zabbix/zabbix_agentd.psk" -k "upload"
~~~

  ![Screenshot](img/procedimento-zabbix/instalacao/linux/instalacao-rhel-03.jpg)

## Overview do zabbix

### Login Zabbix
* Acesse o site do zabbix [Click Aqui](http://srv-zabbix-server.yourdomain.com.br/zabbix)
* Para login utilize o acesso que está salvo no `keepass`;

### Monitoring

#### Dashboard
* Click em Monitoring e em Dashboard;

  ![Screenshot](img/procedimento-zabbix/monitoring/monitoring-01.jpg)

* Click em All dashboard;

  ![Screenshot](img/procedimento-zabbix/monitoring/monitoring-02.jpg)

* Vai ser listado todos os dashboards selecione a DASH que precisa, atualmente utilizamos a `DASH-MONITORING`;

  ![Screenshot](img/procedimento-zabbix/monitoring/monitoring-03.jpg)

* Ao clicar será exibida a dashboard, para mudar click em `All dashboars`;

  ![Screenshot](img/procedimento-zabbix/monitoring/monitoring-04.jpg)

#### Problems

* Click em `Problems`;
* Aqui conseguimos selecionar o host, grupos, triggers, severidade;

  ![Screenshot](img/procedimento-zabbix/monitoring/monitoring-05.jpg)

#### Hosts

* Click em `Hosts`;
* Conseguimos filtrar por grupo, ip, severidade;

  ![Screenshot](img/procedimento-zabbix/monitoring/monitoring-06.jpg)

#### Latest data

* Click em `Latest data`;
* Conseguimos filtrar por grupo, ip, severidade;
* Ao aplicar vamos conseguir visualizar os ultimos dados;

  ![Screenshot](img/procedimento-zabbix/monitoring/monitoring-07.jpg)

### Configuration

#### Host groups

* Click em Configuration > Host Groups;
* Em host groups criamos os grupos onde vamos alocar os hosts adicionados;
* Geralmente eu crio os grupos baseados em numeração:
    * 0 a 99 deixo livre para criar grupos especificos de setor e serviços;
    * 100 a 199 utilizo para serviços de linux;
    * 200 a 299 utilizo para serviços de windows;
    * 300 a 399 utilizo para vmware;
    * 400 a 401 utilizo para serviços de monitoria;
    * 500 a 599 utilizo para serviços SQL;
    * 800 utilizo para Multi OS

  ![Screenshot](img/procedimento-zabbix/configuration/configuration-01.jpg)

* Conseguimos visualizar todos os hosts em seu respectivo grupo;

  ![Screenshot](img/procedimento-zabbix/configuration/configuration-02.jpg)

#### Templates

* Click em Configuration > Templates;

  ![Screenshot](img/procedimento-zabbix/configuration/configuration-01.jpg)

* Conseguimos visualizar todos os templates;
* Geralmente eu crio os templates baseados na numeração utilizada nos hosts groups:
    * 0 a 99 deixo livre para criar grupos especificos de setor e serviços;
    * 100 a 199 utilizo para serviços de linux;
    * 200 a 299 utilizo para serviços de windows;
    * 300 a 399 utilizo para vmware;
    * 400 a 401 utilizo para serviços de monitoria;
    * 500 a 599 utilizo para serviços SQL;
    * 800 utilizo para Multi OS

* Os templates conseguimos criar itens, triggers, graficos;

>Após criar um template com seus itens adicionamos um host a esse template, ao adicionar o host ele vai herdar dos atributos desse template.
>Sempre que vou adicionar um item, prefiro criar um template do que atribuir direto no host, dessa forma é possivel reutilizar os itens e suas triggers em outros hosts caso necessário no futuro.

* Para mais informções sobre templates veja a Documentação [Click aqui](https://www.zabbix.com/documentation/6.0/pt/manual/config/templates)

  ![Screenshot](img/procedimento-zabbix/configuration/configuration-03.jpg)

#### Hosts

* Click em Configuration > Templates;

  ![Screenshot](img/procedimento-zabbix/configuration/configuration-01.jpg)

* Aqui conseguimos visualizar todos os hosts;

  ![Screenshot](img/procedimento-zabbix/configuration/configuration-04.jpg)

## Adicionando dispositivo no monitoramento do zabbix

### Login Zabbix
* Acesse o site do zabbix [Click Aqui](http://srv-zabbix-server.yourdomain.com.br/zabbix)
* Para login utilize o acesso que está salvo no `keepass`;

### Adicionando o novo host

* Click em Configuration > Templates;

  ![Screenshot](img/procedimento-zabbix/configuration/configuration-01.jpg)

* Aqui conseguimos visualizar todos os hosts;

  ![Screenshot](img/procedimento-zabbix/configuration/configuration-04.jpg)

* Click em `Create host`;

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-01.jpg)

### Configurando nome do host

* Na janela aberta adicione as informações do host:
    * Host name: `IP do servidor`;
    * Visible name:
      1. Para os HOSTS utilizo a nomenclatura: HOST-VMWARE-FINALIP - HOST-HYPERV-FINALIP
      2. Para modem: MODEM-FINALIP - Exemplo: MODEM-180;
      3. Para PC: PC-FINALIP;
      4. Para Switch: SW-FINALIP;
      5. Para VM: VM-FINALIP ( NOME DA VM);

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-02.jpg)

### Definindo o template

* Selecionar o template, click em Select;

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-03.jpg)

* Selecione o host groups que deseja para depois selecionar o template relacionado a maquina desejada;

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-04.jpg)

* Após selecionar o host group será exibido os templates relacionados aquele grupo;
* Selecione o template que deseja;

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-05.jpg)

* Feito a seleção vai retornar para a janela conforme imagem abaixo;
* Podemos adicionar quantos templates desejarmos para nosso host, basta clicar em selecionar novamente e seguir os mesmos passos; 

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-06.jpg)

* Vamos clicar em select novamente;

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-07.jpg)

* Vamos clicar no icone imagem abaixo;

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-08.jpg)

* Click em select;

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-09.jpg)

* Selecione o grupo 302;

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-10.jpg)

* Selecione o template vmware guest;

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-11.jpg)

### Definindo o Grupo do host

* Click em select;

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-12.jpg)

* Selecione os grupos desejados;
    * Grupos para PCs, VMs e Hosts:
      1. Para host fisico: Selecione 001 - Host Fisico, grupo referente ao setor e o template referente ao SO;
      2. Para host vmware: Selecione 300 , 301 e o template referente ao host vmware;
      3. Para vms: Selecione o host group do hostvmware em que essa vm está alocada, 300, 302 e o template referente ao SO 100 ou 200;
      4. Para modem: 009 - Modem;
      5. Para Switch: 002 - Switch;

    * Para facilitar pode abrir em uma nova guia um host com as mesmas especificações que está adicionando e seguir o modelo dele;

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-13.jpg)

* Após selecão será exibido os grupos selecionados na janela anterior;

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-14.jpg)

### Adicionando interfaces

* Em interfaces click em `Add`;
* Tipo de interface: 
    * Selecione Agent caso tenha instalado o agente do zabbix;
    * Selecione SNMP para switchs e roteadores (Nesse caso temos que habilitar a funcionalidade no dispositivo)

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-15.jpg)

* Informe o IP e mantenha as configurações como na imagem abaixo;

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-16.jpg)

### Habilitando Inventário

* Click em Inventory e em Automatic;

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-17.jpg)

### Configurando a PSK

* Abrir a pasta de rede e o arquivo PSK001.txt;
* Copie o conteúdo do arquivo;

~~~shell
\\SRV-FILESERVER\Infraestrutura\ZABBIX\PSK001.txt
~~~

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-18.jpg)

* Volte para a página do zabbix;
* Click em `Encryption` Click em `PSK`;
* Desmarque a opção `No encryption`;
* Marque a opção `PSK`;
* Defina em PSK identity: PSK001
* Cole em PSK: O conteudo que copiou do arquivo PSK001;
* Click em ADD;

~~~shell
\\SRV-FILESERVER\Infraestrutura\ZABBIX\PSK001.txt
~~~

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-19.jpg)

### Visualizando o host adicionado

* Com o host adicionaro pesquise por ele;
* Vai visualizar o host click em `Discovery`;

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-20.jpg)

* Para windows em alguns casos que não precise monitorar os serviços vamos desabilitar a regra `Windows service discovery` (Essa regra descobre todos os serviços e do windows);
* Basta clicar em `Enabled` que vai desativar a regra.

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-21.jpg)

* Finalizado todos os passos o host vai ter sido adicionado com sucesso e em alguns minutos já vai começar a reconhecer os itens e coletar dados.

## Adicionando hostvmare no monitoramento do zabbix

### Habilitar plugin para consultas do zabbix

#### Acessar o vsphere

* Acesse o vsphere, usuario e senha de acesso;
* Adicionar no monitoramento do zabbix;
    * Click no servidor;
    * Click em Configuration;
    * Click em Advanced Settings;
    * Click em Config;
    * Click em HostAgent;
    * Click em Plugins;
    * Click em solo;
    * Marque o checkbox e click em OK.

  ![Screenshot](img/procedimento-zabbix/add-host-vmware/hostvmware-01.jpg)

#### Coletar o UUID do Hypervisor

* Acesse um navegador de sua preferencia:
    * URL (altere o ip para o do servidor atual): https://IP/mob/?moid=ha-host&doPath=hardware.systemInfo

  ![Screenshot](img/procedimento-zabbix/add-host-vmware/hostvmware-02.jpg)

* Informe usuario e senha de acesso ao host, padrão que utilizamos;
  ![Screenshot](img/procedimento-zabbix/add-host-vmware/hostvmware-03.jpg)

* Na página aberta precisamos copiar o `UUID`;
* Copie o conteudo e cole em um bloco de notas, vamos precisar dessa informação no zabbix;

  ![Screenshot](img/procedimento-zabbix/add-host-vmware/hostvmware-04.jpg)
### Adicionando o Host no Zabbix

### Login Zabbix
* Acesse o site do zabbix [Click Aqui](http://srv-zabbix-server.yourdomain.com.br/zabbix)
* Para login utilize o acesso que está salvo no `keepass`;

### Adicionando o novo Host groups

* Click em Configuration > Host groups;

  ![Screenshot](img/procedimento-zabbix/configuration/configuration-01.jpg)

* Click em `Create host group`;

  ![Screenshot](img/procedimento-zabbix/add-host-vmware/hostvmware-05.jpg)

* Adicione o nome do grupo;
    * Por padrão utilizo a classe 300 e o final do IP do host;
    * Nome de exemplo: 358 - VMware Host 58;
    * Click em adicionar.

  ![Screenshot](img/procedimento-zabbix/add-host-vmware/hostvmware-06.jpg)

### Adicionando o novo host

* Click em Configuration > Templates;

  ![Screenshot](img/procedimento-zabbix/configuration/configuration-01.jpg)

* Click em `Create host`;

  ![Screenshot](img/procedimento-zabbix/add-host-vmware/hostvmware-07.jpg)

### Configurando nome do host

* Na janela aberta adicione as informações do host:
    * Host name: `IP do servidor`;
    * Visible name:
      1. Para os HOSTS utilizo a nomenclatura: HOST-VMWARE-FINALIP

  ![Screenshot](img/procedimento-zabbix/add-host-vmware/hostvmware-08.jpg)

### Definindo o template

* Selecionar o template, click em Select;

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-03.jpg)

* Selecione o host groups que deseja para depois selecionar o template relacionado a maquina desejada;

  ![Screenshot](img/procedimento-zabbix/add-host-vmware/hostvmware-09.jpg)

* Após selecionar o host group será exibido os templates relacionados aquele grupo;
* Selecione o template que deseja;

  ![Screenshot](img/procedimento-zabbix/add-host-vmware/hostvmware-10.jpg)

* Feito a seleção vai retornar para a janela conforme imagem abaixo;
* Podemos adicionar quantos templates desejarmos para nosso host, basta clicar em selecionar novamente e seguir os mesmos passos; 

  ![Screenshot](img/procedimento-zabbix/add-host-vmware/hostvmware-11.jpg)

### Definindo o Grupo do host

* Click em grupos click em select;
* Selecione os grupos:
  * 300 - VMware;
  * 301 - VMware Hypervisor;
  * Grupo relacionado ao host vmware (exemplo 353 - VMware Host 53);

  ![Screenshot](img/procedimento-zabbix/add-host-vmware/hostvmware-12.jpg)

### Adicionando interfaces

* Em interfaces click em `Add`;
* Tipo de interface: 
    * Selecione Agent caso tenha instalado o agente do zabbix;

  ![Screenshot](img/procedimento-zabbix/add-host-vmware/hostvmware-13.jpg)

* Informe o IP e mantenha as configurações como na imagem abaixo;

  ![Screenshot](img/procedimento-zabbix/add-host-vmware/hostvmware-14.jpg)

### Confirgurando a Macro

* Click em Macros;
* Adicione as informações como abaixo:
    * Macro: {$VMWARE.HV.UUID}
    * Value: Aqui adicionamos o valor da `UUID` que copiamos no inicio para o bloco de notas;
    * Description: UUID of hypervisor.

  ![Screenshot](img/procedimento-zabbix/add-host-vmware/hostvmware-15.jpg)

### Habilitando Inventário

* Click em Inventory e em Automatic;

  ![Screenshot](img/procedimento-zabbix/add-host/add-host-17.jpg)

### Concluindo a adição

* Após realizar todos os passos agora basta clicar em adicionar;
* Agora basta aguardar iniciar a sincronia dos dados

  ![Screenshot](img/procedimento-zabbix/add-host-vmware/hostvmware-16.jpg)

## Adicionando Mapas

### Criando o Mapa HOSTs
* Click em Monitoring > Maps > Create map

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-01.jpg)

* Adicione as informações abaixo:
    * Name: MAP-HOST-IP
    * Width: 650
    * Height: 300
    * Map element label type: Element name
    * Click em adicionar

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-02.jpg)

#### Editando o Mapa

* Volte na pagina dos mapas, click no mapa que acabamos de criar;

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-03.jpg)

* Na pagina aberta, click em `Edit map`;

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-04.jpg)

* Na pagina aberta, em Map element click em `Add`;

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-05.jpg)

#### Adicionando o elemento HOST VMWARE

* Click no elemento;
    * Type selecione: host
    * Label adicione::
~~~shell
{HOST.IP}
{HOST.NAME}
{HOST.CONN}
~~~
    * Host: Click em select

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-06.jpg)

* Remova o host group já selecionado e click em select;

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-07.jpg)

* Na janela aberta selecione o host group do host vmare que vamos selecionar;

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-08.jpg)

* Na lista de hosts selecione o nosso host vmware;

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-09.jpg)

* Em icons selecione o icone `Server_vmware_(200)`;
* Click em Apply

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-10.jpg)

* Em icons selecione o icone `Server_vmware_(200)`;

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-10.jpg)

#### Adicionando os elementos VMs

* Em Map element click em `Add` novamente;

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-05.jpg)

* Click no elemento recem adicionado;
    * Type selecione: host
    * Label adicione::
~~~shell
{HOST.IP}
{HOST.NAME}
{HOST.CONN}
~~~
    * Host: Click em select

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-06.jpg)

* Agora podemos aproveitar o host group já selecionado e selecionar a vm desse host;

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-11.jpg)

* Em icons selecione o icone `Windows_(64)`;
* Click em Apply

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-12.jpg)

* Pressione ctrl e selecione o servidor e a vm;
* Em Link: click em Add;
* Vai ser criado um vinculo entre os dois elementos;
* Caso o host possua mais VMs refaça os passo realizados para VM;

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-13.jpg)

#### Organizando o MAPA

* Após adicionar todos os elementos eu faço uma centralização dos elementos no mapa;
* Feitos todos os passos finalizamos a adição do mapa;
* Click em `Update`

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-14.jpg)

### Criando Mapa VMs

* Click em Monitoring > Maps > Create map

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-01.jpg)

* Adicione as informações abaixo:
    * Name: VM-IP
    * Width: 130
    * Height: 150
    * Icon Highlight: Marque o checkbox
    * Mark elements on trigger status change: Marque o checkbox
    * Map element label type: Element name
    * Click em adicionar

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-vms-01.jpg)

#### Editando o Mapa

* Volte na pagina dos mapas, pesquise em name pelo mapa que acabou de criar
* Click em Apply;
* Click no mapa criado;

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-vms-02.jpg)

* Na pagina aberta, click em `Edit map`;

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-vms-03.jpg)

* Na pagina aberta, em Map element click em `Add`;

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-05.jpg)

#### Adicionando os elementos VMs

* Em Map element click em `Add` novamente;

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-05.jpg)

* Click no elemento recem adicionado;
    * Type selecione: host
    * Label adicione::
~~~shell
{HOST.IP}
{HOST.NAME}
{HOST.CONN}
~~~
    * Host: Click em select

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-06.jpg)

* Remova o host group já selecionado e click em select;

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-host-07.jpg)

* Na janela aberta selecione algum host group que a vm que estamos adicionando pertence;
  
  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-vms-04.jpg)

* Selecione a vm que deseja adicionar no mapa;

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-vms-05.jpg)

* Em icons selecione o icone `Windows_(64)`;
* Em Coordinates: 
    * X: 43 
    * Y: 43
* Click em Apply

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-vms-06.jpg)

#### Update MAPA

* Feitos todos os passos finalizamos a adição do mapa;
* Click em `Update`

  ![Screenshot](img/procedimento-zabbix/add-maps/add-maps-vms-07.jpg)


## Adicionando Dashboards

### Criando Dasboard

* Click em Monitoring > Dashboard > Create dashboard

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-01.jpg)

* Click em Monitoring > Dashboard > Create dashboard
    * Name: DASH-HOST-IP
    * Click em Apply

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-02.jpg)


### Editando a DASH do HOST

#### Abrindo uma DASH de Modelo

* Click com o direito em `All dashboards` > Click em `Abrir link em nova aba`

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-03.jpg)

* Eu seleciono um host que possuí um modelo de VM que eu possa reaproveitar;
* Como estou criando uma dash de um host com uma vm de leitura, vou selecionar um que já possua essa configuração.

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-04.jpg)

* Com a dash aberta click na DASH do host primeiro;
* Click nos 3 pontos e depois em copy;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-05.jpg)

#### Adicionando a DASH Copiada

* Volte na página da DASH que estamos criando;
* Click na seta do lado de `ADD` > Click em `Paste page`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-06.jpg)

* Click na pagina `Page 1`;
* Click nos 3 pontos e depois em `Delete`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-07.jpg)

#### Editando o nome da Pagina

* Na Dash que colamos Click nos 3 pontos e depois em `Properties`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-08.jpg)

* Altere o Name para o IP final do respectivo host;
* Click em Apply

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-09.jpg)

#### Editando o mapa

* Click na engrenagem do primeiro item conforme imagem abaixo;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-10.jpg)

* Altere o nome para o de seu host;
* Click em Select;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-11.jpg)

* Selecione o map correspondente ao seu host;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-12.jpg)

* Confira os dados e click em Apply;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-13.jpg)

#### Editando Problems

* Agora click na engrenagem de `Problems`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-14.jpg)

* Remova todos os itens conforme imagem abaixo;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-15.jpg)

* Agora click `Select`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-16.jpg)

* Selecione o Host Group do Host;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-17.jpg)

* Selecione os Hosts;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-18.jpg)

* Selecione todos os Hosts pertencentes ao Host Group do Host VMware;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-19.jpg)

* Confira se selecionou tudo e click em `Apply`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-20.jpg)

#### Editando CPU cores

* Click na engrenagem de `CPU cores`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-21.jpg)

* Click em `Select`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-22.jpg)

* Click no `x` do Host;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-23.jpg)

* Click no `Select`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-24.jpg)

* Selecione o Host group do respectivo host vmware;
* Agora selecione o HOST VMWARE;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-25.jpg)

* Na próxima tela selecione o item `VMware: CPU cores`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-26.jpg)

* Na próxima tela click em `Apply`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-27.jpg)

#### Editando Memory Size

* Click na engrenagem de `Memory size`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-28.jpg)

* Click em `Select`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-29.jpg)

* Como já selecionamos o host na etapa anterior aqui basta selecionarmos o item que desejamos;
* Apenas certifique que o host é de fato o que estamos editando;
* Selecione o item `VMware: Total memory`

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-30.jpg)

* Certifique de que selecionou o item correto e click em apply;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-31.jpg)

#### Editando CPU threads

* Click na engrenagem de `CPU threads`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-32.jpg)

* Click em `Select`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-33.jpg)

* Como já selecionamos o host na etapa anterior aqui basta selecionarmos o item que desejamos;
* Apenas certifique que o host é de fato o que estamos editando;
* Selecione o item `VMware: CPU threads`

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-34.jpg)


* Certifique de que selecionou o item correto e click em apply;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-35.jpg)

#### Editando NUM VMs

* Click na engrenagem de `NUM VMs`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-36.jpg)

* Click em `Select`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-37.jpg)

* Como já selecionamos o host na etapa anterior aqui basta selecionarmos o item que desejamos;
* Apenas certifique que o host é de fato o que estamos editando;
* Selecione o item `VMware: Number of guest VMs`

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-38.jpg)

* Certifique de que selecionou o item correto e click em apply;
  
  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-39.jpg)

#### Editando CPU usage

* Click na engrenagem de `CPU usage`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-40.jpg)

* Click no `x` conforme imagem abaixo para remover o host atual;
  
  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-41.jpg)


* Click em `Select`;
  
  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-42.jpg)

* Como já selecionamos o host na etapa anterior aqui basta selecionarmos o item que desejamos;
* Apenas certifique que o host é de fato o que estamos editando;
* Selecione o item `Host VMware`

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-43.jpg)

* Certifique de que selecionou o item correto e click em apply;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-44.jpg)

#### Editando Memory usage

* Click na engrenagem de `Memory usage`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-45.jpg)

* Click no `x` conforme imagem abaixo para remover o host atual;
  
  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-46.jpg)


* Click em `Select`;
  
  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-47.jpg)

* Como já selecionamos o host na etapa anterior aqui basta selecionarmos o item que desejamos;
* Apenas certifique que o host é de fato o que estamos editando;
* Selecione o item `Host VMware`

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-48.jpg)

* Certifique de que selecionou o item correto e click em apply;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-49.jpg)

#### Editando DATASTORE

* Click na engrenagem do `DATASTORE`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-50.jpg)

* Altere o nome para o mesmo que está configurado no VSPHERE;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-51.jpg)

* Para pegar o nome abra o VSPHERE como na imagem abaixo e copie o nome do datastore que deseja configurar

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-52.jpg)

* Click em `Select`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-53.jpg)

* Como já selecionamos o host na etapa anterior aqui basta selecionarmos o item que desejamos;
* Apenas certifique que o host é de fato o que estamos editando;
* Selecione o item `VMware: Free space on datastore NOME DO SEU DATASTORE (percentage)`

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-54.jpg)

* Certifique de que selecionou o item correto e click em apply;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-55.jpg)

#### Editando TOTAL SIZE DATASTORE

* Click na engrenagem do `DATASTORE`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-56.jpg)

* Altere o nome para o mesmo que está configurado no VSPHERE;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-57.jpg)

* Para pegar o nome abra o VSPHERE como na imagem abaixo e copie o nome do datastore que deseja configurar

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-52.jpg)

* Click em `Select`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-58.jpg)

* Como já selecionamos o host na etapa anterior aqui basta selecionarmos o item que desejamos;
* Apenas certifique que o host é de fato o que estamos editando;
* Selecione o item `VMware: Total size of datastore NOME DO SEU DATASTORE`

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-59.jpg)

* Certifique de que selecionou o item correto e click em apply;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-60.jpg)

#### Adicionar mais DATASTORES

* Click nos 3 ponstos do DASTAORE e depois em copy;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-61.jpg)

* Depois click em uma área livre na dash com o botão esquerdo;
* Click em Paste widget;
* Faça os mesmos passos para o total size;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-62.jpg)

* Após realizar a cópia realize a edição dos widgets seguindo os passos:
    * Editando DATASTORE
    * Editando TOTAL SIZE DATASTORE

#### Conclusão Edição da Dash Hostvmare

* Vamos visualizar todos os itens já com as informações de nosso HOST;
* Caso esteja editando apenas o HOST click em Save Changes;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-63.jpg)

### Editando a DASH das VMs ou PCs

#### Abrindo uma DASH de Modelo

* Click com o direito em `All dashboards` > Click em `Abrir link em nova aba`

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-03.jpg)

* Eu seleciono um host que possuí um modelo de VM que eu possa reaproveitar;
* Como estou criando uma dash de um host com uma vm de leitura, vou selecionar um que já possua essa configuração.

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-04.jpg)

* Com a dash aberta click na DASH da vm;
* Click nos 3 pontos e depois em copy;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-01.jpg)

#### Adicionando a DASH Copiada

* Volte na página da DASH que estamos criando;
* Click na seta do lado de `ADD` > Click em `Paste page`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-06.jpg)

#### Editando o nome da Pagina

* Na Dash que colamos Click nos 3 pontos e depois em `Properties`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-02.jpg)

* Altere o Name para mesmo nome de rede e entre parenteses o final do IP;
* Click em Apply

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-03.jpg)

#### Editando o mapa

* Click na engrenagem do primeiro item conforme imagem abaixo;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-04.jpg)

* Altere o nome para o de seu host;
* Click em Select;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-05.jpg)

* Selecione o map correspondente ao seu host;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-06.jpg)

* Confira os dados e click em Apply;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-07.jpg)

#### Editando CPU usage

* Click na engrenagem de `CPU usage`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-08.jpg)

* Click no `x` conforme imagem abaixo para remover o host atual;
  
  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-09.jpg)


* Click em `Select`;
  
  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-10.jpg)

* Como já selecionamos o host na etapa anterior aqui basta selecionarmos o item que desejamos;
* Apenas certifique que o host é de fato o que estamos editando;
* Selecione o item `Host VMware`

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-11.jpg)

* Certifique de que selecionou o item correto e click em apply;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-12.jpg)

#### Editando Memory usage

* Click na engrenagem de `Memory usage`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-13.jpg)

* Click no `x` conforme imagem abaixo para remover o host atual;
  
  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-14.jpg)


* Click em `Select`;
  
  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-15.jpg)

* Como já selecionamos o host na etapa anterior aqui basta selecionarmos o item que desejamos;
* Apenas certifique que o host é de fato o que estamos editando;
* Selecione o item `Host VMware`

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-16.jpg)

* Certifique de que selecionou o item correto e click em apply;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-17.jpg)

#### Editando Problems

* Agora click na engrenagem de `Problems`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-18.jpg)

* Remova todos os itens conforme imagem abaixo;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-19.jpg)

* Agora click `Select`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-20.jpg)

* Selecione o Host Group do Host;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-17.jpg)

* Selecione os Hosts;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-18.jpg)

* Selecione a VM;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-21.jpg)

* Confira se selecionou tudo e click em `Apply`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-22.jpg)

#### Editando Network traffic

* Click na engrenagem de `Network traffic`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-23.jpg)

* Click em `Select`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-24.jpg)

* Click no `x` do Host;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-25.jpg)

* Click no `Select`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-26.jpg)

* Selecione o Host group do respectivo host vmware;
* Agora selecione a VM;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-27.jpg)

* Na próxima tela selecione o item `Interface ({#IFALIAS}) - {#IFNAME}: Network traffic`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-28.jpg)

* Na próxima tela caso possua mais de uma placa de rede, altere as colunas e linhas de acordo com as placas de rede que possuir a VM
* Feito os ajustes click em `Apply`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-29.jpg)

#### Editando CPU cores

* Click na engrenagem de `CPU cores`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-21.jpg)

* Click em `Select`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-22.jpg)

* Click no `x` do Host;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-23.jpg)

* Click no `Select`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-24.jpg)

* Selecione o Host group do respectivo host vmware;
* Agora selecione o HOST VMWARE;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-30.jpg)

* Na próxima tela selecione o item `Number of cores`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-31.jpg)

* Na próxima tela click em `Apply`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-32.jpg)

#### Editando Memory Size

* Click na engrenagem de `Memory size`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-28.jpg)

* Click em `Select`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-hosts-29.jpg)

* Como já selecionamos o host na etapa anterior aqui basta selecionarmos o item que desejamos;
* Apenas certifique que o host é de fato o que estamos editando;
* Selecione o item `Total memory`

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-33.jpg)

* Certifique de que selecionou o item correto e click em apply;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-34.jpg)

#### Editando Disk space usage

* Click na engrenagem do `Disk space usage`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-35.jpg)

* Click em `Select`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-36.jpg)

* Como já selecionamos o host na etapa anterior aqui basta selecionarmos o item que desejamos;
* Apenas certifique que o host é de fato o que estamos editando;
* eSelecione o item `{#FSLABEL}({#FSNAME}): Disk space usage`

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-37.jpg)

* Na próxima tela caso possua mais de um disco, altere as colunas e linhas de acordo com os discos que possuir na VM
* Certifique de que selecionou o item correto e click em apply;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-38.jpg)

#### Editando Disk average queue length

* Click na engrenagem do `Disk average queue length`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-39.jpg)

* Click em `Select`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-40.jpg)

* Como já selecionamos o host na etapa anterior aqui basta selecionarmos o item que desejamos;
* Apenas certifique que o host é de fato o que estamos editando;
* Selecione o item `{#DEVNAME}: Disk average queue length`

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-41.jpg)

* Na próxima tela caso possua mais de um disco, altere as colunas e linhas de acordo com os discos que possuir na VM
* Certifique de que selecionou o item correto e click em apply;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-42.jpg)

#### Editando Disk utilization and queue

* Click na engrenagem do `Disk utilization and queue`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-43.jpg)

* Click em `Select`;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-44.jpg)

* Como já selecionamos o host na etapa anterior aqui basta selecionarmos o item que desejamos;
* Apenas certifique que o host é de fato o que estamos editando;
* Selecione o item `{#DEVNAME}: Disk utilization and queue`

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-45.jpg)

* Na próxima tela caso possua mais de um disco, altere as colunas e linhas de acordo com os discos que possuir na VM
* Certifique de que selecionou o item correto e click em apply;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-46.jpg)

#### Conclusão Edição da Dash VM ou PC

* Vamos visualizar todos os itens já com as informações de nossa VM ou PC;
* Click em Save Changes;

  ![Screenshot](img/procedimento-zabbix/add-dashboard/add-dashboard-vms-47.jpg)
