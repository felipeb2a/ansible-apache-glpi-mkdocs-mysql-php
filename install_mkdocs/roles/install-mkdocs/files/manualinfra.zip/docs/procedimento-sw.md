# Procedimento Switchs

## Padrão de Nomenclaturas Descrição de Portas

### Host VMWARE
* Se for possível identificar qual a VMNIC correspondente utilize a segunda descrição, deixando documentado a porta fisica no host e a porta identificada no vmware
* Para o Zyxel troque o pipe (|) por hífen (-)

~~~shell
description "HOST 16.65 | ONP03 | PP7P20"
description "HOST 16.29 | OF01P03 | vmnic9 | PP5P21"
~~~

### Host Faixa 0
~~~shell
description "HOST 0.65 | ONP03 | PP7P20"
~~~

### Uplink Entre SWs Gerenciavéis
~~~shell
description "UPLINK | DELL N2048 | 0.253 | SG01P35"
~~~

### Uplink Entre SWs Não Gerenciavéis
~~~shell
description "UPLINK | MODENS RESIDENCIAIS | SNG03P48"
~~~

### NAS
~~~shell
description "NAS02 0.79 | ONP01 | PP4P23"
~~~

### Operadora
~~~shell
description "OPERADORA | CENTURY | PP8P04"
~~~

## Comandos SW DELL N2048

* Site dell documentação 01  [Click aqui](https://www.dell.com/support/kbdoc/pt-br/000104748/como-configurar-os-modos-de-switchport-em-switches-dell-emc-networking-s%C3%A9rie-n)

* Site dell documentação 02  [Click aqui](https://www-dell-com.translate.goog/support/kbdoc/en-us/000104854/how-to-create-vlans-on-dell-emc-networking-n-series-switches?_x_tr_sl=en&_x_tr_tl=pt&_x_tr_hl=pt&_x_tr_pto=tc)

* Site dell documentação Stack  [Click aqui](https://www.dell.com/support/kbdoc/pt-br/000121374/como-empilhar-e-desempilhar-um-membro-no-comutador-dell-emc-networking-n4000)
* Site dell video Stack  [Click aqui](https://www.dell.com/support/contents/pt-br/videos/videoplayer/como-empilhar-switches-para-o-dell-networking-n2000/6079805145001)

### Exibir Portas Ativas
~~~shell
show interfaces status
~~~

#### Exibir apenas portas do sw 1 ou 2 em stack
~~~shell
show interfaces status | include Gi1/
show interfaces status | include Te1/

#PARA STACK 2

show interfaces status | include Gi2/
show interfaces status | include Te2/
~~~

### Exibir Todas as Configurações do SW
~~~shell
show running-config
~~~

### VLAN

#### Habilitar Console
~~~shell
enable
~~~

#### Entra no modo de configuração
~~~shell
configure
~~~

#### Selecionar interface vlan
~~~shell
vlan 10
~~~

#### Descrição selecione a interface vlan
~~~shell
name "CONTEUDO"
~~~

#### Desativar a interface vlan
~~~shell
no vlan 700
~~~

### Stack Ports

#### Habilitar Console
~~~shell
enable
~~~

#### Entra no modo de configuração
~~~shell
configure
~~~

#### Show Ports
~~~shell
show switch stack-ports
show switch
~~~

#### Habilitar Portas Stack
~~~shell
stack
stack-port twentygigabitethernet 1/0/1 stack
stack-port twentygigabitethernet 1/0/2 stack
~~~

#### Remover Membro do Stack
~~~shell
stack
no member 2
~~~

### Habilitar Modo Trunk

* Acessar o SW dell que deseja via ssh, usuário e senha de acesso estão no keepass;

#### Habilitar Console
~~~shell
enable
~~~

#### Entra no modo de configuração
~~~shell
configure
~~~

#### Selecionar interface
~~~shell
interface gigabitethernet 1/0/PORTA

#PARA STACK 2

interface gigabitethernet 2/0/PORTA
~~~

#### Selecionar range de interfaces

* Todas as alterações serão realizadas para as portas selecionadas.

~~~shell
interface range gigabitethernet 1/0/20-43

#PARA STACK 2

interface range gigabitethernet 2/0/20-43
~~~

#### Exibir configurações da interface
~~~shell
show interfaces switchport gigabitethernet 1/0/PORTA
show running-config interface gigabitethernet 1/0/PORTA

#PARA STACK 2

show interfaces switchport gigabitethernet 2/0/PORTA
show running-config interface gigabitethernet 2/0/PORTA
~~~

#### Colocar porta em Shutdown
~~~shell
shutdown
~~~

#### Tirar a porta de Shutdown
~~~shell
no shutdown
~~~

#### Limpar configurações da Porta
~~~shell
no switchport general pvid
no description
no switchport access vlan
no switchport trunk allowed vlan
no switchport mode
no spanning-tree portfast
no green-mode eee
no spanning-tree disable
no switchport trunk native vlan
~~~

#### Habilitar modo trunk
~~~shell
switchport mode trunk
no green-mode eee
spanning-tree portfast
no spanning-tree disable
~~~

#### Habilitar todas as vlans
~~~shell
switchport trunk allowed vlan all
~~~

#### Habilitar apenas algumas vlans
~~~shell
switchport trunk allowed vlan 100,400
~~~

#### Descrição selecione a porta

~~~shell
description "CONTEUDO"
~~~

#### Verifique se as configurações foram aplicadas
~~~shell
show interfaces switchport gigabitethernet 1/0/PORTA
show running-config interface gigabitethernet 1/0/PORTA

#PARA O STACK 2

show interfaces switchport gigabitethernet 2/0/PORTA
show running-config interface gigabitethernet 2/0/PORTA
~~~


#### Sair do modo de configuração
~~~shell
exit
~~~

#### Sair do modo em
~~~shell
exit
~~~

#### Salvar as configurações realizadas
~~~shell
write
~~~

#### Selecionar interface
~~~shell
interface gigabitethernet 1/0/PORTA

#PARA STACK 2

interface gigabitethernet 2/0/PORTA
~~~

### Habilitar Modo Access

#### Habilitar Console
~~~shell
enable
~~~

#### Entra no modo de configuração
~~~shell
configure
~~~

#### Selecionar interface
~~~shell
interface gigabitethernet 1/0/PORTA

#PARA STACK 2

interface gigabitethernet 2/0/PORTA
~~~

#### Selecionar range de interfaces

* Todas as alterações serão realizadas para as portas selecionadas.

~~~shell
interface range gigabitethernet 1/0/20-43

#PARA STACK 2

interface range gigabitethernet 2/0/20-43
~~~

#### Exibir configurações da interface
~~~shell
show interfaces switchport gigabitethernet 1/0/PORTA
show running-config interface gigabitethernet 1/0/PORTA

#PARA STACK 2

show interfaces switchport gigabitethernet 2/0/PORTA
show running-config interface gigabitethernet 4/0/PORTA
~~~

#### Limpar configurações da Porta
~~~shell
no switchport general pvid
no description
no switchport access vlan
no switchport trunk allowed vlan
no switchport mode
no spanning-tree portfast
no green-mode eee
no spanning-tree disable
no switchport trunk native vlan
~~~

#### Habilitar modo Access

* Acessar o SW dell que deseja via ssh, usuário e senha de acesso estão no keepass;

~~~shell
switchport mode access
no green-mode eee
spanning-tree disable
~~~

#### Habilitar vlan
~~~shell
switchport access vlan 100
~~~

#### Descrição selecione a porta
~~~shell
description "CONTEUDO"
~~~

#### Verifique se as configurações foram aplicadas
~~~shell
show interfaces switchport gigabitethernet 1/0/PORTA
show running-config interface gigabitethernet 1/0/PORTA

#PARA STACK 2

show interfaces switchport gigabitethernet 2/0/PORTA
show running-config interface gigabitethernet 2/0/PORTA
~~~

#### Sair do modo de configuração
~~~shell
exit
~~~

#### Sair do modo enable
~~~shell
exit
~~~

#### Salvar as configurações realizadas
~~~shell
write
~~~

#### Show PORT SPF
~~~shell
show interfaces switchport tengigabitethernet 1/0/1

#PARA STACK 2

show interfaces switchport tengigabitethernet 2/0/1
~~~
