# Tologia de Rede

## PFSense

### Completa
```mermaid
graph TD

INTERNET[fa:fa-cloud Internet]

INTERNET --- FW[fa:fa-shield Firewall 0.250<br/> fa:fa-info Rede Servers <br/> fa:fa-network-wired VLAN 100 <br/> fa:fa-sitemap 172.16.16.254/24 <br/> fa:fa-info Rede Faixa 1 <br/> fa:fa-network-wired VLAN 200 <br/> fa:fa-sitemap 192.168.1.250/24 <br/> fa:fa-info Rede Faixa 0 <br/> fa:fa-network-wired VLAN 400 <br/> fa:fa-sitemap 192.168.0.250/24 <br/> fa:fa-info Link Internet 01 <br/> fa:fa-network-wired VLAN 500 <br/> fa:fa-sitemap 100.0.100.2/28 <br/> fa:fa-info Link Internet 02 <br/> fa:fa-network-wired VLAN 501 <br/> fa:fa-sitemap 200.0.100.2/29 <br/> fa:fa-info Link Internet 03 <br/> fa:fa-network-wired VLAN 502 <br/> fa:fa-sitemap 200.0.250.2/29 <br/> fa:fa-info Rede Idracs <br/> fa:fa-network-wired VLAN 506 <br/> fa:fa-sitemap 10.10.0.254/24]

FW --- SW1(fa:fa-random SWITCH DELL 1 <br/>  fa:fa-sitemap 192.168.0.254/24 <br/>)

FW --- SW2(fa:fa-random SWITCH DELL 2 <br/>  fa:fa-sitemap 192.168.0.253/24 <br/>)

SW1 --- SW(fa:fa-random SWITCH CORE <br/> )

SW2 --- SW(fa:fa-random SWITCH CORE <br/> )

SW --- VLAN100[fa:fa-network-wired VLAN 100 <br/> fa:fa-sitemap 172.16.16.0/24 <br/> fa:fa-info Rede Servers]

VLAN100 --- VMWARE[fa:fa-server Servidor VMWare <br/> fa:fa-sitemap 172.16.16.0/24 <br/> fa:fa-info PowerEdge DELL]

SW --- VLAN200[fa:fa-network-wired VLAN 200 <br/> fa:fa-sitemap 192.168.1.0/24 <br/> fa:fa-info Rede Estações] 

VLAN200 --- DESKTOP[fa:fa-desktop Desktop <br/> fa:fa-sitemap 192.168.1.0/24 <br/> fa:fa-info PC ou NOT]

SW --- VLAN400[fa:fa-network-wired VLAN 400 <br/> fa:fa-sitemap 192.168.0.0/24 <br/> fa:fa-info Rede Faixa 0]

VLAN400 --- VM[fa:fa-server VM Virtualizada <br/> fa:fa-sitemap 192.168.0.0/24 <br/> fa:fa-info VMs]

SW --- VLAN500[fa:fa-network-wired VLAN 500 <br/> fa:fa-sitemap 100.0.100.1/28 <br/> fa:fa-info Link Internet 01]

VLAN500 --- FW-1[fa:fa-shield Firewall <br/> fa:fa-sitemap 192.168.0.250 <br/> fa:fa-info Link Internet 01]

SW --- VLAN501[fa:fa-network-wired VLAN 501 <br/> fa:fa-sitemap 200.0.100.1/29 <br/> fa:fa-info Link Internet 02]

VLAN501 --- FW-2[fa:fa-shield Firewall <br/> fa:fa-sitemap 192.168.0.250 <br/> fa:fa-info Link Internet 02]

SW --- VLAN502[fa:fa-network-wired VLAN 502 <br/> fa:fa-sitemap 200.0.250.1/29 <br/> fa:fa-info Link Internet 03]

VLAN502 --- FW-4[fa:fa-shield Firewall <br/> fa:fa-sitemap 192.168.0.250 <br/> fa:fa-info Link Internet 03]

SW --- VLAN506[fa:fa-network-wired VLAN 506 <br/> fa:fa-sitemap 10.10.0.0/24 <br/> fa:fa-info Rede Idracs]

VLAN506 --- IDRACs[fa:fa-shield IDRAC <br/> fa:fa-sitemap 10.10.0.0/24]







INTERNET --- FWFAIXA2[fa:fa-shield Firewall 2.250 <br/> fa:fa-info Link Internet 03 <br/> fa:fa-network-wired VLAN 502 <br/> fa:fa-sitemap 200.0.250.3/29 <br/> fa:fa-info Link Internet 02 <br/> fa:fa-network-wired VLAN 501 <br/> fa:fa-sitemap 200.0.100.3/29 <br/> fa:fa-info Link Internet 01 <br/> fa:fa-network-wired VLAN 500 <br/> fa:fa-sitemap 100.0.100.3/28 <br/> fa:fa-info rede faixa 2 <br/> fa:fa-network-wired VLAN 505 <br/> fa:fa-sitemap 192.168.2.250/24 <br/> fa:fa-info Rede Faixa 0 <br/> fa:fa-network-wired VLAN 400 <br/> fa:fa-sitemap 192.168.0.230/24]

FWFAIXA2 --- SW1(fa:fa-random SWITCH DELL 1 <br/>  fa:fa-sitemap 192.168.0.254/24 <br/>)

FWFAIXA2 --- SW2(fa:fa-random SWITCH DELL 2 <br/>  fa:fa-sitemap 192.168.0.253/24 <br/>)

SW1 --- SW(fa:fa-random SWITCH CORE <br/> )

SW2 --- SW(fa:fa-random SWITCH CORE <br/> )

SW --- VLAN400[fa:fa-network-wired VLAN 400 <br/> fa:fa-sitemap 192.168.0.0/24 <br/> fa:fa-info Rede Faixa 0]

VLAN400 --- FWFAIXA2250[fa:fa-shield Firewall <br/> fa:fa-sitemap 192.168.0.250 <br/> fa:fa-info FWFAIXA2 Principal]

SW --- VLAN500[fa:fa-network-wired VLAN 500 <br/> fa:fa-sitemap 100.0.100.1/28 <br/> fa:fa-info Link Internet 01]

VLAN500 --- FWFAIXA2-1[fa:fa-shield Firewall <br/> fa:fa-sitemap 192.168.2.250 <br/> fa:fa-info Link Internet 01]

SW --- VLAN501[fa:fa-network-wired VLAN 501 <br/> fa:fa-sitemap 200.0.100.1/29 <br/> fa:fa-info Link Internet 02]

VLAN501 --- FWFAIXA2-2[fa:fa-shield Firewall <br/> fa:fa-sitemap 192.168.2.250 <br/> fa:fa-info Link Internet 02]

SW --- VLAN502[fa:fa-network-wired VLAN 502 <br/> fa:fa-sitemap 200.0.250.1/29 <br/> fa:fa-info Link Internet 03]

VLAN502 --- FWFAIXA2-4[fa:fa-shield Firewall <br/> fa:fa-sitemap 192.168.2.250 <br/> fa:fa-info Link Internet 03]

SW --- VLAN505[fa:fa-network-wired VLAN 505 <br/> fa:fa-sitemap 192.168.2.0/24 <br/> fa:fa-info Rede Faixa 2]

VLAN505 --- VMPCsFAIXA2[fa:fa-server VMs e PCs <br/> fa:fa-sitemap 192.168.2.0/24 <br/> fa:fa-info Todas VMs e PCs  que precisam da rede faixa 2]

```

### Principal
```mermaid
graph TD

INTERNET[fa:fa-cloud Internet]

INTERNET --- FW[fa:fa-shield Firewall 0.250<br/> fa:fa-info Rede Servers <br/> fa:fa-network-wired VLAN 100 <br/> fa:fa-sitemap 172.16.16.254/24 <br/> fa:fa-info Rede Faixa 1 <br/> fa:fa-network-wired VLAN 200 <br/> fa:fa-sitemap 192.168.1.250/24 <br/> fa:fa-info Rede Faixa 0 <br/> fa:fa-network-wired VLAN 400 <br/> fa:fa-sitemap 192.168.0.250/24 <br/> fa:fa-info Link Internet 01 <br/> fa:fa-network-wired VLAN 500 <br/> fa:fa-sitemap 100.0.100.2/28 <br/> fa:fa-info Link Internet 02 <br/> fa:fa-network-wired VLAN 501 <br/> fa:fa-sitemap 200.0.100.2/29 <br/> fa:fa-info Link Internet 03 <br/> fa:fa-network-wired VLAN 502 <br/> fa:fa-sitemap 200.0.250.2/29 <br/> fa:fa-info Rede Idracs <br/> fa:fa-network-wired VLAN 506 <br/> fa:fa-sitemap 10.10.0.254/24]

FW --- SW1(fa:fa-random SWITCH DELL 1 <br/>  fa:fa-sitemap 192.168.0.254/24 <br/>)

FW --- SW2(fa:fa-random SWITCH DELL 2 <br/>  fa:fa-sitemap 192.168.0.253/24 <br/>)

SW1 --- SW(fa:fa-random SWITCH CORE <br/> )

SW2 --- SW(fa:fa-random SWITCH CORE <br/> )

SW --- VLAN100[fa:fa-network-wired VLAN 100 <br/> fa:fa-sitemap 172.16.16.0/24 <br/> fa:fa-info Rede Servers]

VLAN100 --- VMWARE[fa:fa-server Servidor VMWare <br/> fa:fa-sitemap 172.16.16.0/24 <br/> fa:fa-info PowerEdge DELL]

SW --- VLAN200[fa:fa-network-wired VLAN 200 <br/> fa:fa-sitemap 192.168.1.0/24 <br/> fa:fa-info Rede Estações] 

VLAN200 --- DESKTOP[fa:fa-desktop Desktop <br/> fa:fa-sitemap 192.168.1.0/24 <br/> fa:fa-info PC ou NOT]

SW --- VLAN400[fa:fa-network-wired VLAN 400 <br/> fa:fa-sitemap 192.168.0.0/24 <br/> fa:fa-info Rede Faixa 0]

VLAN400 --- VM[fa:fa-server VM Virtualizada <br/> fa:fa-sitemap 192.168.0.0/24 <br/> fa:fa-info VMs]

SW --- VLAN500[fa:fa-network-wired VLAN 500 <br/> fa:fa-sitemap 100.0.100.1/28 <br/> fa:fa-info Link Internet 01]

VLAN500 --- FW-1[fa:fa-shield Firewall <br/> fa:fa-sitemap 192.168.0.250 <br/> fa:fa-info Link Internet 01]

SW --- VLAN501[fa:fa-network-wired VLAN 501 <br/> fa:fa-sitemap 200.0.100.1/29 <br/> fa:fa-info Link Internet 02]

VLAN501 --- FW-2[fa:fa-shield Firewall <br/> fa:fa-sitemap 192.168.0.250 <br/> fa:fa-info Link Internet 02]

SW --- VLAN502[fa:fa-network-wired VLAN 502 <br/> fa:fa-sitemap 200.0.250.1/29 <br/> fa:fa-info Link Internet 03]

VLAN502 --- FW-4[fa:fa-shield Firewall <br/> fa:fa-sitemap 192.168.0.250 <br/> fa:fa-info Link Internet 03]

SW --- VLAN506[fa:fa-network-wired VLAN 506 <br/> fa:fa-sitemap 10.10.0.0/24 <br/> fa:fa-info Rede Idracs]

VLAN506 --- IDRACs[fa:fa-shield IDRAC <br/> fa:fa-sitemap 10.10.0.0/24]

```

### Rede Faixa 2
```mermaid
graph TD

INTERNET[fa:fa-cloud Internet]

INTERNET --- FWFAIXA2[fa:fa-shield Firewall 2.250 <br/> fa:fa-info Link Internet 03 <br/> fa:fa-network-wired VLAN 502 <br/> fa:fa-sitemap 200.0.250.3/29 <br/> fa:fa-info Link Internet 02 <br/> fa:fa-network-wired VLAN 501 <br/> fa:fa-sitemap 200.0.100.3/29 <br/> fa:fa-info Link Internet 01 <br/> fa:fa-network-wired VLAN 500 <br/> fa:fa-sitemap 100.0.100.3/28 <br/> fa:fa-info rede faixa 2 <br/> fa:fa-network-wired VLAN 505 <br/> fa:fa-sitemap 192.168.2.250/24 <br/> fa:fa-info Rede Faixa 0 <br/> fa:fa-network-wired VLAN 400 <br/> fa:fa-sitemap 192.168.0.230/24]

FWFAIXA2 --- SW1(fa:fa-random SWITCH DELL 1 <br/>  fa:fa-sitemap 192.168.0.254/24 <br/>)

FWFAIXA2 --- SW2(fa:fa-random SWITCH DELL 2 <br/>  fa:fa-sitemap 192.168.0.253/24 <br/>)

SW1 --- SW(fa:fa-random SWITCH CORE <br/> )

SW2 --- SW(fa:fa-random SWITCH CORE <br/> )

SW --- VLAN400[fa:fa-network-wired VLAN 400 <br/> fa:fa-sitemap 192.168.0.0/24 <br/> fa:fa-info Rede Faixa 0]

VLAN400 --- FWFAIXA2250[fa:fa-shield Firewall <br/> fa:fa-sitemap 192.168.0.250 <br/> fa:fa-info FWFAIXA2 Principal]

SW --- VLAN500[fa:fa-network-wired VLAN 500 <br/> fa:fa-sitemap 100.0.100.1/28 <br/> fa:fa-info Link Internet 01]

VLAN500 --- FWFAIXA2-1[fa:fa-shield Firewall <br/> fa:fa-sitemap 192.168.2.250 <br/> fa:fa-info Link Internet 01]

SW --- VLAN501[fa:fa-network-wired VLAN 501 <br/> fa:fa-sitemap 200.0.100.1/29 <br/> fa:fa-info Link Internet 02]

VLAN501 --- FWFAIXA2-2[fa:fa-shield Firewall <br/> fa:fa-sitemap 192.168.2.250 <br/> fa:fa-info Link Internet 02]

SW --- VLAN502[fa:fa-network-wired VLAN 502 <br/> fa:fa-sitemap 200.0.250.1/29 <br/> fa:fa-info Link Internet 03]

VLAN502 --- FWFAIXA2-4[fa:fa-shield Firewall <br/> fa:fa-sitemap 192.168.2.250 <br/> fa:fa-info Link Internet 03]

SW --- VLAN505[fa:fa-network-wired VLAN 505 <br/> fa:fa-sitemap 192.168.2.0/24 <br/> fa:fa-info Rede Faixa 2]

VLAN505 --- VMPCsFAIXA2[fa:fa-server VMs e PCs <br/> fa:fa-sitemap 192.168.2.0/24 <br/> fa:fa-info Todas VMs e PCs  que precisam da rede faixa 2]

```

### Rede Faixa 78 Proxy
```mermaid
graph TD

INTERNET[fa:fa-cloud Internet]

INTERNET --- MODENS[fa:fa-random MODENS RESIDENCIAIS e 4G PROXY <br/> fa:fa-sitemap 192.168.78.0/24]

MODENS --- PROXY[fa:fa-shield PROXY <br/> fa:fa-info Rede Proxy <br/> fa:fa-network-wired VLAN 601 <br/> fa:fa-sitemap 192.168.78.254/24 <br/> fa:fa-info Link Internet 02 <br/> fa:fa-network-wired VLAN 501 <br/> fa:fa-sitemap 200.0.100.4/29 <br/> fa:fa-info Link Internet 01 <br/> fa:fa-network-wired VLAN 500 <br/> fa:fa-sitemap 100.0.100.4/28]

SW1(fa:fa-random SWITCH DELL 1 <br/>  fa:fa-sitemap 192.168.0.254/24 <br/>)
SW2(fa:fa-random SWITCH DELL 2 <br/>  fa:fa-sitemap 192.168.0.253/24 <br/>)

SW1 --- SW(fa:fa-random SWITCH CORE <br/> )

SW2 --- SW(fa:fa-random SWITCH CORE <br/> )

SW --- VLAN500[fa:fa-network-wired VLAN 500 <br/> fa:fa-sitemap 100.0.100.1/28 <br/> fa:fa-info Link Internet 01]

VLAN500 --- PROXY[fa:fa-shield PROXY <br/> fa:fa-info Rede Proxy <br/> fa:fa-network-wired VLAN 601 <br/> fa:fa-sitemap 192.168.78.254/24 <br/> fa:fa-info Link Internet 02 <br/> fa:fa-network-wired VLAN 501 <br/> fa:fa-sitemap 200.0.100.4/29 <br/> fa:fa-info Link Internet 01 <br/> fa:fa-network-wired VLAN 500 <br/> fa:fa-sitemap 100.0.100.4/28]

SW --- VLAN501[fa:fa-network-wired VLAN 501 <br/> fa:fa-sitemap 200.0.100.1/29 <br/> fa:fa-info Link Internet 02]

VLAN501 --- PROXY[fa:fa-shield PROXY <br/> fa:fa-info Rede Proxy <br/> fa:fa-network-wired VLAN 601 <br/> fa:fa-sitemap 192.168.78.254/24 <br/> fa:fa-info Link Internet 02 <br/> fa:fa-network-wired VLAN 501 <br/> fa:fa-sitemap 200.0.100.4/29 <br/> fa:fa-info Link Internet 01 <br/> fa:fa-network-wired VLAN 500 <br/> fa:fa-sitemap 100.0.100.4/28]

SW --- VLAN601[fa:fa-network-wired VLAN 601 <br/> fa:fa-sitemap 192.168.78.0/24 <br/> fa:fa-info Rede Proxy]

VLAN601 --- PROXY[fa:fa-shield PROXY <br/> fa:fa-info Rede Proxy <br/> fa:fa-network-wired VLAN 601 <br/> fa:fa-sitemap 192.168.78.254/24 <br/> fa:fa-info Link Internet 02 <br/> fa:fa-network-wired VLAN 501 <br/> fa:fa-sitemap 200.0.100.4/29 <br/> fa:fa-info Link Internet 01 <br/> fa:fa-network-wired VLAN 500 <br/> fa:fa-sitemap 100.0.100.4/28]

VLAN601 --- VM-PROXY[fa:fa-shield VMs e PCs QUE UTILIZAM PROXY <br/> fa:fa-sitemap 192.168.78.0/24]

```
