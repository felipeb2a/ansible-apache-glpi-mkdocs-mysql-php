# Tologia CPD

## RACK01
```mermaid
graph TD
RACK01[fa:fa-server RACK01]

RACK01 --- NAS01(fa:fa-database NAS-01 <br/>  fa:fa-sitemap 192.168.0.100 <br/> fa:fa-info DOMAIN-0198 )

NAS01 --- HYPERV[fa:fa-server FISICO - HYPERV-01 <br/> fa:fa-sitemap 192.168.0.101 <br/> fa:fa-info PowerEdge T630 DELL <br/> fa:fa-info DOMAIN-0183] 

HYPERV --- VMWARE-40[fa:fa-server VMWARE - SRV-SLNVM40 <br/> fa:fa-sitemap 172.16.16.40 <br/> fa:fa-info PowerEdge T630 DELL <br/> fa:fa-info DOMAIN-0184]

```

## NAS-SOLU01
```mermaid
graph LR
NAS-01(fa:fa-hdd NAS-SOLU01 <br/> fa:fa-sitemap 192.168.0.100 <br/> fa:fa-wrench Memória 8GB <br/> fa:fa-wrench CPU AMD Ryzen Embedded V1500 Quad-core 2.20GHz <br/> fa:fa-hdd 2 SSDs 1TB <br/> fa:fa-hdd 8 HDs 4TB RAID 5)

NAS-01 --- VM-WEB-01(fa:fa-terminal VM-WEB-01 <br/> fa:fa-sitemap 192.168.0.110 <br/> fa:fa-hdd ISCI_NAS01 E: 15TB )

```

### Armazenamento Geral
  ![Screenshot](img/rede-topologia-cpd-rack-01/nas-01/nas-01-armazenamento-geral.jpg)

## VISTA-HYPERV-01
```mermaid
graph LR
VISTA-HYPERV-01(fa:fa-server VISTA-HYPERV-01 <br/>  fa:fa-sitemap REDE <br/> fa:fa-sitemap vEthernet - VREDE <br /> 192.168.0.100 <br /> 255.255.255.0 <br /> 192.168.0.1 <br /> 192.168.0.1 <br /> 192.168.0.2 <br /> fa:fa-wrench Memória 256GB <br/> fa:fa-wrench CPU 2 CPUs Intel-R Xeon CPU E5-2696 v4 2.20GHz <br/> fa:fa-hdd 1 HD 560GB <br/> fa:fa-hdd 1 SSD 2TB <br/> fa:fa-info Windows 10 PRO)

VISTA-HYPERV-01 --- WINDOWS10-145(fa:fa-info WINDOWS10-145 <br/> fa:fa-info Windows 10 <br/>  fa:fa-sitemap 192.168.0.145 <br/>  fa:fa-sitemap VREDE <br/> fa:fa-wrench CPU 12 vCPUs <br/> fa:fa-wrench Memória 30GB <br/> fa:fa-hdd 1 HD 100GB)

```

### VISTA-HYPERV-01 100 CONFIGURAÇÕES

#### Softwares

  ![Screenshot](img/rede-topologia-cpd-rack-01/vista-hyperv-01/conf-geral-01.jpg)

#### Programas

  ![Screenshot](img/rede-topologia-cpd-rack-01/vista-hyperv-01/programas-01.jpg)

#### Discos

  ![Screenshot](img/rede-topologia-cpd-rack-01/vista-hyperv-01/discos-01.jpg)

#### VMs

  ![Screenshot](img/rede-topologia-cpd-rack-01/vista-hyperv-01/vms-01.jpg)

#### VM `WINDOWS10-145`

  ![Screenshot](img/rede-topologia-cpd-rack-01/vista-hyperv-01/vm-windows10-45-conf-01.jpg)

#### Placas de Rede

  ![Screenshot](img/rede-topologia-cpd-rack-01/vista-hyperv-01/placas-de-rede.jpg)

* Placa de Rede `REDE`
	* Habilitado apenas as opções `Driver de Protocolo LLDP da Microsoft` e `Comutador Virtual Extensível Hyper-V`

* Placa de Rede `vEthernet (Default Switch)`
	* Desabilitado apenas as opções `Protocolo do Multiplexador de Adaptador de Rede da Microsoft` e `Comutador Virtual Extensível Hyper-V`

  ![Screenshot](img/rede-topologia-cpd-rack-01/vista-hyperv-01/placas-de-rede-vethernet-default-switch.jpg)

* Placa de Rede `vEthernet (VREDE)`
	* Desabilitado apenas as opções `Protocolo IP Versão 4 - TCP/IPv4`,`Protocolo do Multiplexador de Adaptador de Rede da Microsoft` e `Comutador Virtual Extensível Hyper-V`
	
  ![Screenshot](img/rede-topologia-cpd-rack-01/vista-hyperv-01/placas-de-rede-vethernet-vrede.jpg)

### VISTA-HYPERV-01 100 FOTOS SERVER

#### Foto 01

  ![Screenshot](img/rede-topologia-cpd-rack-01/vista-hyperv-01/server/vm-119-01.jpg)

### VM-145 CONFIGs SO

#### Geral

  ![Screenshot](img/rede-topologia-cpd-rack-01/vista-hyperv-01/vm-145/win/vm-145-conf-geral-01.jpg)

#### Discos

  ![Screenshot](img/rede-topologia-cpd-rack-01/vista-hyperv-01/vm-145/win/vm-145-discos.jpg)

#### Ethernets

  ![Screenshot](img/rede-topologia-cpd-rack-01/vista-hyperv-01/vm-145/win/vm-145-ethernet.jpg)

#### Ethernet REDE

  ![Screenshot](img/rede-topologia-cpd-rack-01/vista-hyperv-01/vm-145/win/vm-145-ethernet-rede.jpg)
   
#### Ethernet VEthernet

  ![Screenshot](img/rede-topologia-cpd-rack-01/vista-hyperv-01/vm-145/win/vm-145-ethernet-vethernet.jpg)
  
#### Hostname

  ![Screenshot](img/rede-topologia-cpd-rack-01/vista-hyperv-01/vm-145/win/vm-145-hostname.jpg)
  
#### Programas Instalados

  ![Screenshot](img/rede-topologia-cpd-rack-01/vista-hyperv-01/vm-145/win/vm-145-programas-instalados.jpg)
  
#### Recursos

  ![Screenshot](img/rede-topologia-cpd-rack-01/vista-hyperv-01/vm-145/win/vm-145-taskmanager.jpg)

## SRV-SLNVM-40
```mermaid
graph LR
SRV-SLNVM-40(fa:fa-server SRV-SLNVM-40<br/> fa:fa-sitemap VMNIC0 <br/> fa:fa-sitemap REDE - VLAN 1 <br/> fa:fa-sitemap VM Network <br/> fa:fa-sitemap Management Network - VLAN 100 <br/> 172.16.16.40 <br/> 255.255.255.0 <br/> 172.16.16.254 <br/> 192.168.0.1 <br/> 192.168.0.2 <br/> fa:fa-wrench Memória 32GB <br/> fa:fa-wrench CPU 2 CPUs Intel-R Xeon CPU E5-2696 v4 2.20GHz <br/> fa:fa-hdd 2 HD 300GB - RAID1  <br/> fa:fa-info VMWare ESXI 6)

SRV-SLNVM-40 --- VM-21(fa:fa-info VM-21 <br /> fa:fa-info Serviço executado pela vm <br />fa:fa-info Windows 11 <br/>  fa:fa-sitemap 192.168.0.21 <br/>  fa:fa-sitemap REDE <br/> fa:fa-wrench CPU 88 vCPUs <br/> fa:fa-wrench Memória 24GB <br/> fa:fa-hdd 1 HD 80GB)

```

### SRV-SLNVM-40 CONFIGURAÇÕES

#### Configuração geral

 ![Screenshot](img/rede-topologia-cpd-rack-01/srv-slnvm-40/conf-geral-01.jpg)

#### VMs

  ![Screenshot](img/rede-topologia-cpd-rack-01/srv-slnvm-40/conf-geral-vms.jpg)

#### Discos

  ![Screenshot](img/rede-topologia-cpd-rack-01/srv-slnvm-40/conf-geral-discos.jpg)

#### DNS

  ![Screenshot](img/rede-topologia-cpd-rack-01/srv-slnvm-40/conf-geral-dns.jpg)

#### Networks

  ![Screenshot](img/rede-topologia-cpd-rack-01/srv-slnvm-40/conf-geral-networks.jpg)

#### Startup

  ![Screenshot](img/rede-topologia-cpd-rack-01/srv-slnvm-40/conf-geral-startup.jpg)

### VM-21 CONFIGs HOSTVMWARE

  ![Screenshot](img/rede-topologia-cpd-rack-01/srv-slnvm-40/vm-21/vmware/vm-21-conf-vmware.jpg)

### VM-21 CONFIGs SO

#### Geral

  ![Screenshot](img/rede-topologia-cpd-rack-01/srv-slnvm-40/vm-21/win/vm-21-conf-geral-01.jpg)

#### Discos

  ![Screenshot](img/rede-topologia-cpd-rack-01/srv-slnvm-40/vm-21/win/vm-21-discos.jpg)

#### Ethernet

  ![Screenshot](img/rede-topologia-cpd-rack-01/srv-slnvm-40/vm-21/win/vm-21-ethernet.jpg)
  
#### Hostname

  ![Screenshot](img/rede-topologia-cpd-rack-01/srv-slnvm-40/vm-21/win/vm-21-hostname.jpg)
  
#### Programas Instalados

  ![Screenshot](img/rede-topologia-cpd-rack-01/srv-slnvm-40/vm-21/win/vm-21-programas-instalados.jpg)
  
#### Recursos

  ![Screenshot](img/rede-topologia-cpd-rack-01/srv-slnvm-40/vm-21/win/vm-21-taskmanager.jpg)
