# E-mail

## Primeiro Acesso Webmail
* Abra o link [Click aqui](https://webmail.yourdomain.com.br/)

* 1 - Insira seu e-mail e senha como na imagem abaixo:

  ![Screenshot](img/email/acesso-webmail-01.jpg)

* 2 - Login efetuado com sucesso, o pop-up que se abrir basta fechar como na imagem abaixo: 

  ![Screenshot](img/email/acesso-webmail-02.jpg)

* 3 - Agora click no seu `E-mail` depois em `Password & Security` na barra principal localizada no topo da página: 

  ![Screenshot](img/email/acesso-webmail-03.jpg)

* 4 - Na página que foi aberta realize a alteração de sua senha, está senha vai ter que atender um nível de segurança mínimo:

  ![Screenshot](img/email/acesso-webmail-04.jpg)

* 5 - Após alteração de sua senha click no ícone `Webmail` na barra principal localizada no topo da página.

  ![Screenshot](img/email/acesso-webmail-05.jpg)

* 6 - Retornando a página inicial role a página até encontrar `Two-Factor Authentication` e click nessa opção.

  ![Screenshot](img/email/acesso-webmail-06.jpg)

* 7 - Click em `Configurar Autenticação de dois fatores`.

  ![Screenshot](img/email/acesso-webmail-07.jpg)

* 8 - Abaixe e instale em seu celular o aplicativo `Google Authenticator` 

  ![Screenshot](img/email/acesso-webmail-08.jpg)

* 9 - Após instalar abra o aplicativo e click no icone `+` e depois em `Ler código QR` como na imagem abaixo

  ![Screenshot](img/email/acesso-webmail-09.jpg)

* 10 - Agora basta apontar sua câmera para a página contendo o QR code aberto

  ![Screenshot](img/email/acesso-webmail-10.jpg)

* 11 - Caso não possuo leitor de QR Code, click no icone `+` e depois em `Inserir chave de configuração`:
    * Nome da conta: `inserir seu e-mail como ilustrado na página no campo CONTA`
    * Chave: `inserir a chave como ilustrado na página no campo CHAVE`
    * Click em Adicionar

  ![Screenshot](img/email/acesso-webmail-11.jpg)

* 12 - Agora execute a etapa 2
    * Em seu aplicativo vai exibir um codigo de 6 numeros referente ao e-mail da solucionare, insira esse número e click em `configurar autenticação de dois fatores`.

  ![Screenshot](img/email/acesso-webmail-12.jpg)

* 13 - Configuração realizada com sucesso exibirá uma página como na imagem abaixo:

  ![Screenshot](img/email/acesso-webmail-13.jpg)

* 14 - Click novamente no ícone `Webamil`:
    * Será solicitado código de acesso, basta informar novamente o código ndo aplicativo.

  ![Screenshot](img/email/acesso-webmail-14.jpg)

* 15 - Finalizado as configurações de segurança vamos acessar o webmail:
    * Na página inicial marque a opção `Open my inbox when I log in`
    * Click em `Open`

  ![Screenshot](img/email/acesso-webmail-15.jpg)

* 16 - Essa é nossa página de e-mail:

  ![Screenshot](img/email/acesso-webmail-16.jpg)

## Acesso Webmail
* Abra o link [Click aqui](https://webmail.yourdomain.com.br/)

* 1 - Insira seu e-mail e senha como na imagem abaixo:

  ![Screenshot](img/email/acesso-webmail-01.jpg)

* 2 - Login efetuado com sucesso, o pop-up que se abrir basta fechar como na imagem abaixo: 

  ![Screenshot](img/email/acesso-webmail-02.jpg)


* 3 - Na página inicial marque a opção `Open my inbox when I log in`
    * Click em `Open`

  ![Screenshot](img/email/acesso-webmail-15.jpg)

* 4 - Essa é nossa página de e-mail: 

  ![Screenshot](img/email/acesso-webmail-16.jpg)

## Configurando em Clientes de E-mail Outlook / Thunderbird

## Configurações IMAP / POP / SMTP

Exemplo   | Valor do exemplo
--------- | ------
Nome de usuário: | your.username@yourdomain.com.br
Senha: | Use a senha da conta de email.
Servidor de entrada: | mail.yourdomain.com.br
IMAP Port: | 993
Servidor de entrada: | mail.yourdomain.com.br
POP3 Port: | 995
Servidor de saída: | mail.yourdomain.com.br
SMTP Port: | 465
IMAP, POP3 e SMTP: | require authentication.