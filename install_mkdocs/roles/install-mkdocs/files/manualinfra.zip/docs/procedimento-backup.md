# Procedimento Backups

## Backup Banco de Dados

### Conferência Backup Banco de Dados

#### Dinâmica do BKP Banco de Dados

Disco   | Tipo Bkp    | Modo       |  Dia                     | Hora  | Origem                                   | Destino
------- | ----------- | ---------- |----------------------- | ----- | ------------------------------------------ | ----------------------------------------- 
NAS     | Full        | Automatico | Seg                     | 02:00 | M:\BKP_CLOUDDB\FULL                       | \\\192.168.3.78\backup\30\M\BKP_CLOUDDB\FULL\
DISCO F | Full        | Automatico | Qua                     | 19:00 | M:\BKP_CLOUDDB\FULL                       | F:\BANCO DE DADOS\BACKUP BD 1\FULL
DISCO F | Diferencial | Automatico | Dom,Seg,Ter,Qua,Qui,Sex | 14:00 | \\\192.168.200.10\n$\BANCOS\BACKUP\DIFF    | F:\BANCO DE DADOS\BACKUP BD 1\DIFERENCIAL
DISCO F | Log         | Automatico | Todos os dias           | 23:08 | \\\192.168.200.10\n$\BANCOS\BACKUP\LOG     | F:\BANCO DE DADOS\BACKUP BD 1\LOG


#### Conferência Backup Banco de Dados Agendador de Tarefas

* Abrir o Agendador de Tarefas > Biblioteca do Agendador > Banco de Dados.
  
  ![Screenshot](img/procedimento-backup/conferencia-backup/agendador-de-tarefas-01.jpg)

* Click em cada job e verifique o histórico de execução.

  ![Screenshot](img/procedimento-backup/conferencia-backup/agendador-de-tarefas-02.jpg)

#### Conferência Backup Banco de Dados Arquivos de Log

* Abrir a pasta com os logs e verificar se nos arquivos consta o aviso de `FALHA` caso esteja `OK` o script foi executado com sucesso.

  ![Screenshot](img/procedimento-backup/conferencia-backup/log-01.jpg)

* Selecione todos os arquivos e pressione `ENTER`.
* Será aberto os arquivos, verifique se consta `OK` em todos os arquivos e poe ir fechando, caso encontre algum com `FALHA` mantenha-o aberto para corrigir a cópia dos arquivos.

  ![Screenshot](img/procedimento-backup/conferencia-backup/log-02.jpg)

#### Conferência Backup Banco de Dados Zabbix

* Conferindo pelo zabbix > na tela inicial na DashBoard `DASH MONITORING` > Tela `Bkp Banco de Dados` conseguimos identificar as falhas

  ![Screenshot](img/procedimento-backup/conferencia-backup/conferencia-02.jpg)
