# Procedimento de Instalação Antivírus CrowdStrike

## Coletar Hash Para Criar Exclusion

* Abrir o Powershell e executar o comando abaixo

~~~shell
Get-FileHash "C:\Folder\software_desejado.exe" -Algorithm SHA256
~~~

## Instalação Windows

### Instalação Manual

* Acessar a pasta onde se encontra o software `\\SRV-FILESERVER\Softwares\Antivirus\CrowdStrike\Windows`;
  ![Screenshot](img/procedimento-antivirus/crowdstrike/caminho-antivirus.jpg)
* Copie a pasta `Estacoes` para o computador onde será instalado o anitírus;
* Abra a pasta e execute o script click em Abrir que será identificado a pasta atual e o arquivo do antivírus automaticamente. Se clicar para executar como administrador a pasta de execução muda e não vai encontrar o arquivo de instalação. (Quando a BAT fechar a instalação terá sido finalizada com exito);
  ![Screenshot](img/procedimento-antivirus/crowdstrike/executar-script-instalacao.jpg)


### Instalação Automática Via GPO

* Primeiro passo acessar um dos ADs
* Acessar a o Gerenciamento de Politica de Grupo;
* Hoje a GPO está aplicada apenas para a OU de teste (Gradativamente vamos aplicando as demais OUs para a instalação automática);
* Para que seja instalado automaticamente basta definir essa GPO na OU desejada e após realizar o restart do PC o antivirus será instalado de forma automática.
  ![Screenshot](img/procedimento-antivirus/crowdstrike/aplicar-gpo.jpg)

## Instalação Linux

### Debian, Ubuntu e derivados

* Copie o pacote de instalação para alguma pasta do computador.

* Comando para instalar o antivirus
~~~shell
sudo dpkg -i falcon-sensor_7.14.0-16703_amd64.deb
~~~

* Remover ID do agente do host
~~~shell
sudo /opt/CrowdStrike/falconctl -d -f --aid
~~~

* Definir seu ID de cliente
~~~shell
sudo /opt/CrowdStrike/falconctl -s --cid="YOUR CID"
~~~

* Iniciar serviço do CrowdStrike
~~~shell
sudo systemctl start falcon-sensor.service
~~~