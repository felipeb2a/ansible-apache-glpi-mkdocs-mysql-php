# Procedimento Instalação VMWare

## Configurando a BIOS

### Configuração da BIOS

* Acesse a Bios do servidor

  ![Screenshot](img/procedimento-instalacao-vmware/bios/01.jpg) 

#### System BIOS

* Ao acessar system bios, acesse a opção `SATA Settings`

  ![Screenshot](img/procedimento-instalacao-vmware/bios/02.jpg) 

* Altere as configurações conforme imagem abaixo

  ![Screenshot](img/procedimento-instalacao-vmware/bios/03.jpg) 

* Altere para o modo UEFI conforme imagem abaixo

  ![Screenshot](img/procedimento-instalacao-vmware/bios/04.jpg) 

* Altere a data e hora para corresponder com o horário e data atual.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/05.jpg) 

* Pressione `Esc` para sair e salve as alterações.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/06.jpg) 

* Pressione `OK`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/07.jpg) 

#### IDRAC Settings

* Acesse as configurações da IDRAC.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/08.jpg) 

* Acesse as configurações de `Network`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/09.jpg) 

* Selecione o NIC `Dedicated`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/10.jpg) 

* Defina o `DNS DRAC NAME` seguindo o padrao de nome.
    * SRV-SLNVM66 - A numeração se refere ao final do IP do servidor o IP utilizado como exemplo é de 172.16.16.66;

  ![Screenshot](img/procedimento-instalacao-vmware/bios/11.jpg) 

* Defina o `IPV4 Settings` como `Enabled`;
* Desabilite o `DHCP`;
* Definir o IP, deve ser validado se o ip está livre
    * Utilizar a nova faixa da `vlan 506`
    * 10.10.0.0/24
    * Se o ip do host é `172.16.16.66` o ip da IDRAC vai seguir o padrao `10.10.0.66`

  ![Screenshot](img/procedimento-instalacao-vmware/bios/12.jpg) 

* Pressione `Esc`
* Acesse a opção `Power Configuration`

  ![Screenshot](img/procedimento-instalacao-vmware/bios/13.jpg) 

* Mantenha as configurações conforme imagem abaixo.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/14.jpg) 

* Pressione `Esc` e acesse `User Configuration`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/15.jpg) 

* Acesse `Change Password` e utilize o mesmo padrão de senha definido para o último servidor.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/16.jpg) 

* Após definir click em `Back`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/17.jpg) 

* Click em `Finish` e salve as alterações.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/18.jpg) 

* Click em `OK`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/19.jpg) 

* Acesse `Device Settings`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/20.jpg) 

* Selecione a `controladora RAID`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/21.jpg) 

* Click em `Configuration Management`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/22.jpg) 

* Click em `Create Virtual Disk`.
    * Caso já exista o disco virtual criado pode apagar e recriar ou utilizar o existente, desde que seja `RAID 1` ou `RAID 5` pelo menos. 

  ![Screenshot](img/procedimento-instalacao-vmware/bios/23.jpg) 

* Selecione o tipo de RAID:
    * Para servidores de leitura ou apenas para instalação do ESXI, utilizamos a `RAID 1`;
    * Quando entregamos 3 ou mais discos utilize `RAID 5`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/24.jpg) 

* Click em `Select Physical Disks`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/25.jpg) 

* Selecione os discos desejados e click em `Apply Changes`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/26.jpg) 

* Click em `Ok`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/27.jpg) 

* Click em `Create Virtual Disk`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/28.jpg) 

* Marque a caixa `Confirm` e click em `Yes`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/29.jpg) 

* Click em `Ok`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/30.jpg) 

* Click em `Virtual Disk Management`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/31.jpg) 

* Click o disco virtual que acabou de criar.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/32.jpg) 

* Selecione a operação `Fast Initialization`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/33.jpg) 

* Click em `Go`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/34.jpg) 

* Marque a caixa `Confirm` e click em `Yes`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/35.jpg) 

* Click em `Ok`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/36.jpg) 

* Aguarde finalizar a `Fast Initialization`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/37.jpg) 

* Finalizado click em `Back` e depois em `Finish`.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/38.jpg) 

* Click em `Finish` de novo.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/39.jpg) 

* Click em `Yes`.
* Feito todos os passos estará finalizado a configuração da BIOS.

  ![Screenshot](img/procedimento-instalacao-vmware/bios/40.jpg) 

## Configurando Host VMWare

### Configurando o Host VMWare

* Após instalação do VMWare utilizando as versões que possuímos, realize as configurações abaixo.

#### Configuração pós Instalação

* Após carregar o SO da VMWare Pressione `F2`.

  ![Screenshot](img/procedimento-instalacao-vmware/config-host-vmware/01.jpg) 

* Informe o usuario e senha padrão configurados.

  ![Screenshot](img/procedimento-instalacao-vmware/config-host-vmware/02.jpg) 

* Click em `Configure Management Network`.

  ![Screenshot](img/procedimento-instalacao-vmware/config-host-vmware/03.jpg) 

* Click em `Network Adapters`.

  ![Screenshot](img/procedimento-instalacao-vmware/config-host-vmware/04.jpg) 

* Veja qual vmnic está habilitada.
    * Por padrão sempre utilizamos a vmnic 0 a não ser que a vmnic 0 seja SFP utilizamos a primeira porta padrão RJ45;

  ![Screenshot](img/procedimento-instalacao-vmware/config-host-vmware/05.jpg) 

* Click em `VLAN (optional)`.

  ![Screenshot](img/procedimento-instalacao-vmware/config-host-vmware/06.jpg) 

* Definir a VLAN `100`.
  * Click em `Enter`.

  ![Screenshot](img/procedimento-instalacao-vmware/config-host-vmware/07.jpg) 

* Click em `IPVU Configurations`.

  ![Screenshot](img/procedimento-instalacao-vmware/config-host-vmware/08.jpg) 

* Definir o IP seguindo nossa planilha de controle de IPs disponiveis.
    * Pressione `Enter` após finalizar as configurações

  ![Screenshot](img/procedimento-instalacao-vmware/config-host-vmware/09.jpg) 

* Click em `IPV6 Configuration`.
    * Desabilite conforme imagem abaixo.
    * Pressione `Enter` após finalizar as configurações

  ![Screenshot](img/procedimento-instalacao-vmware/config-host-vmware/10.jpg) 

* Click em `DNS Configuration`.
    * Configure conforme imagem abaixo, definindo o Hostname com o padrão: SRV-SLNVM39 - 39 se refere ao final do ip desse host utilizado como exemplo.
    * Pressione `Enter` após finalizar as configurações

  ![Screenshot](img/procedimento-instalacao-vmware/config-host-vmware/11.jpg) 

* Click em `Custom DNS Suffixes`.
    * Configure conforme imagem abaixo.

  ![Screenshot](img/procedimento-instalacao-vmware/config-host-vmware/12.jpg) 

* Click em `Esc`.
    * Pressione `Y` para aplicar as mudanças.

  ![Screenshot](img/procedimento-instalacao-vmware/config-host-vmware/13.jpg) 

* Aguarde o restart

  ![Screenshot](img/procedimento-instalacao-vmware/config-host-vmware/14.jpg) 

## Configurando o VCenter

### Configurações VCenter

* Para adicionar no Vcenter tem que ser a versão esxi 6.0, as versões acima o acesso é apenas pela web.

#### Adicionar Host no VCenter

* Acesse o VSPHERE CLIENT e acesse o vcenter 
    * IP: 172.16.16.1

* Após acessar click com o direito em `HOSTS`

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/01.jpg) 

* Click em `Add Host`

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/02.jpg) 

* Informe o IP, usuario e senha do novo Host.

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/03.jpg) 

* Click em sim.

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/04.jpg) 

* Click em Next.

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/05.jpg) 

* Selecione uma licença.

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/06.jpg) 

* Click em Next.

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/07.jpg) 

* Selecione o location Your Domain.

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/08.jpg) 

* Click em Finish.

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/09.jpg) 

* Aguarde finalizar a adição do novo host.

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/10.jpg) 

* Após finalizar veja na lista o novo Host.

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/11.jpg) 

* Click no Host adicionado e depois click em `Summary`.
    * Renomear o datastore.

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/12.jpg) 

* Utilize o mesmo padrão conforme imagem abaixo.
    * 39 - DS 1 - RAID 1 - 2 SAS 300GB (ESXI);
    * A nomenclatura se refere no inico ao final do ip do host;
    * DS significa datastore referenciando se é 1 ou 2 e assim por diante;
    * RAID qual a o tipo de RAID configurado;
    * Quantidade de discos no RAID;
    * Tamanho dos discos utilizados;
    * Por fim se é o disco que está instalado o ESXI. 

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/13.jpg) 

* Agora click em `Configuration`.
* Click em `Networking`;
* Click em `Properties`.

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/14.jpg) 

* Agora click em `Add`.

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/15.jpg) 

* Selecione `Virtual Machine`.

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/16.jpg) 

* Adicionando acesso as redes.
    * Redes mais utilizadas:
    * REDE_ - VLAN 1;

* Click em Next após adicionar as informações conforme imagem abaixo.

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/17.jpg) 

* Click em `Finish`.

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/18.jpg) 

* Agora click em `Advanced Settings`.

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/19.jpg) 

* Click em `Config` > `HostAgent` > `Plugins` > `solo`.
* Habilite a opção como na imagem abaixo;
* Essa configuração é necessária para captura de informações no zabbix.

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/20.jpg) 

* Click em `Virtual Machine Startup/Shutdown` > click em `Properties`.

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/21.jpg) 

* Click em `Allow`;
* Mova a maquina virtual presente no host para star automatico, após restart ou desligamento do host.
* Realizado todos os passos finalizamos as configurações básicas de configuração do vmware

  ![Screenshot](img/procedimento-instalacao-vmware/vmware/22.jpg) 
