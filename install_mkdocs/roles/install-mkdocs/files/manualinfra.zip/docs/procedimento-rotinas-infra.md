# Procedimento Rotinas Infra

## Padrão Nomenclatura

* PC-WIN-DOMAIN-0000
* PC-LIN-DOMAIN-0000
* NOT-WINDOMAIN-0000
* NOT-LINDOMAIN-0000
* RASP-DOMAIN-0000
* ORANGE-DOMAIN-0000
* VM-DOMAINXXXX

## Restaurar Imagem Padrão PC/NOT

### Criar Pendrive Bootavel

* Crie um pendrive bootavel, geralmente utilizo:
    * Rufus;
    * YUMI
    * Balena Etcher;

* Utilize a iso abaixo, acessando pelo servidor 30 e depois o NAS03:

~~~ssh
\\SRV-FILESERVER\backup\BACKUP_ACRONIS\ISO
~~~

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/01.jpg)

### Copiar Imagem Padrao

* Utilize a iso abaixo:

~~~ssh
\\SRV-FILESERVER\backup\BACKUP_ACRONIS\IMG\PADRAO PC-NOT
\\SRV-FILESERVER\backup\BACKUP_ACRONIS\IMG\PADRAO PC-DEV
~~~

* Copie a Imagem para um HD Externo ou Pendrive.


  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/02.jpg)

### Restaurando a Imagem

#### Passo 1 - Boot Acronis

* Realizar boot no pendrive da ISO do Acronis;

#### Passo 2 - Recue Media

* Selecione a opção `Rescue Media`, aguarde carregar

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/03.jpg)
#### Passo 3 - Configure Network

* Caso não vá utilizar a imagem pela REDE pule para o passo 04 [Click aqui](#passo-4-manage-this-machine-locally)

* Selecione a opção `Configure network`

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/04.jpg)

* Caso esteja em DHCP vai estar um ip configurado

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/05.jpg)

* Caso não esteja em DHCP desmarque a opção `Auto configuration`;
* Configure um ip disponivel e click em OK.

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/06.jpg)

#### Passo 4 - Manage this machine locally

* Click em `Manage this machine locally`

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/07.jpg)

* Click em `Recover`

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/08.jpg)

* Click em `Required`

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/09.jpg)

* Click em `Browse`

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/10.jpg)

* Possuímos as opções abaixo para restaurar uma imagem:
    * Cloud storage: Caso possua uma conta na ACRONIS ativa conseguimos puxar a imagem conectando o usario e senha;
    * Local folders: É a que vamos utilizar conecte o HD Externo para que possamos pegar o arquivo da imagem; [Click Aqui](#passo-5-selecionando-imagem-para-restore)
    * Network folders: Podemos conectar atravé da rede, necessário compartilhar a pasta em rede e vamos precisar conectar com o usuario e senha de rede para liberar o acesso e acessar os arquivos de imagem. [Click Aqui](#passo-7-selecionando-imagem-para-restore-network)

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/11.jpg)

#### Passo 5 - Selecionando Imagem Para Restore

* Selecione `Local foders` > Depois o `HD Externo` > e selecione a pasta para onde copiou a imagem;
* Click em OK;

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/12.jpg)

* Selecione a imagem que deseja restaurar;
* Selecione o Backup;
* Altere o `Backup contents:` para Disks conforme imagem abaixo.

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/13.jpg)

* Marque o `Disk 1` que deseja restaurar e click em OK.

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/14.jpg)

* As configurações devem estar como na imagem abaixo basta clicar em OK;

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/15.jpg)

* Agora basta aguardar o restore finalizar

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/16.jpg)

* Restore finalizado feche as janelas e na ultima janela click em `Turn off`;
* Após a máquina desligar, remova o HD Externo e Pendrive e ligue a máquina.

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/17.jpg)

#### Passo 6 - Configurando o Windows

##### Renomear Máquina

* Antes de qualquer procedimento renomear a máquina utilizando nosso padrão de `Nomenclatura`.[Click Aqui](#padrao-nomenclatura)

##### Ativando o Windows
* Após a máquina estar ligada ative o windows update;
    * Abrir o C: e acessar a pasta `BLOQUEAR SERVICOS WIN UPDATE` execute o software e habilite o serviço do windows update;

* Caso a máquina possua licença OEM será vinculado automaticamente ao Windows;

* Caso não esteja tente ativar alterando a chave da licença como na imagem abaixo, caso ainda não consiga tente pelo CMD que está logo abaixo da imagem a seguir.

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/18.jpg)

* Execute o CMD como administrador e execute o comando abaixo

~~~ssh
slmgr -ipk chave-do-windows-aqui
~~~

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/19.jpg)

##### Instalar Antivirus

* Instale o antivirus padrão utilizado;

##### Instalar o GLPI

* Instale o GLPI e sincronize as configurações do maquina;

##### Zabbix

* Necessário alterar hostname para o IP da maquina atual;

##### Maquinas de DEV

* As maquinas do DEV já está com antivirus e glpi instalado, basta verificar se subiu na plataforma do antivirus e sincronizar o GLPI;
* Necessário alterar os IPs para algum IP disponivel;

#### Passo 7 - Selecionando Imagem Para Restore Network

* Selecione `Network foders` > Depois o servidor nesse caso selecionei o 30 `VISTABKP-01`.

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/network/01.jpg)

* Será solicitado usuário e senha de rede, informe um usuário que possua permissão de acesso.

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/network/02.jpg)

* Selecione o compartilhamento que contém as imagens do acronis.

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/network/03.jpg)

* Selecione a imagem que deseja restaurar;
* Selecione o Backup;
* Altere o `Backup contents:` para Disks conforme imagem abaixo.

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/network/04.jpg)

* Marque o `Disk 1` que deseja restaurar e click em OK.

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/network/05.jpg)

* As configurações devem estar como na imagem abaixo basta clicar em OK;

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/network/06.jpg)

* Agora basta aguardar o restore finalizar

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/network/07.jpg)

* Restore finalizado feche as janelas e na ultima janela click em `Turn off`;
* Após a máquina desligar, remova o HD Externo e Pendrive e ligue a máquina.

  ![Screenshot](img/procedimento-rotinas-infra/restaurar-imagem-padrao-pc-not/17.jpg)

* Siga o passo a seguir para ativação do windows . [Click Aqui](#passo-6-configurando-o-windows)

## Restaurar Imagem Padrão RASP/ORANGE

### Copiar Imagem Padrao RASP/ORANGE

* Utilize a iso abaixo, acessando pelo servidor 30 e depois o NAS03:

~~~ssh
\\SRV-FILESERVER\backup\ISOs RASPBERRY & ORANGE
~~~

* Copie a Imagem para o computador que vai restaurar a imagem.

  ![Screenshot](img/procedimento-rotinas-infra/rasp-orange-imagem-padrao/01.jpg)

### Gravar SDCARD Windows

* Conecte o adaptador USB com o SDCARD no PC;
* Com o arquivo da imagem já disponivel utilize um dos softwares abaixo para gravar a imagem no SDCARD:
    * Rufus;
    * YUMI
    * Balena Etcher;

* Utilize a iso que copiamos no primeiro passo.

### Gravar SDCARD Linux

* Conecte o adaptador USB com o SDCARD no PC;
* Abrir o terminal;
* Listar os discos:
~~~shell
sudo fdisk -l

## encontre a unidade correspondente ao SDCARD (Exemplo: "/dev/sdb")
~~~

* Executar o comando para voltar a imagem do pc para o sdcard:

* ORANGE PI
    * O arquivo do comando abaixo tem que existir para funcionar, `/home/usuario/Documentos/ORANGEPI/orangepi_08052024.img`
~~~shell
sudo dd if=/home/usuario/Documentos/ORANGEPI/orangepi_08052024.img of=/dev/sdb bs=1M
~~~

* RASPBERRY PI
    * O arquivo do comando abaixo tem que existir para funcionar, `/home/usuario/Documentos/RASPBERRYPI/raspberrypi_19022024.img`
~~~shell
sudo dd if=/home/usuario/Documentos/RASPBERRYPI/raspberrypi_19022024.img of=/dev/sdb bs=1M
~~~

### Comandos Para Criar Imagem Linux
* Abrir o terminal;

* Listar os discos:

~~~shell
sudo fdisk -l
## Encontre a unidade correspondente ao SDCARD (Exemplo: "/dev/sdb")
~~~

* Executar o comando para criar uma imagem do sdcard para seu PC:    

* ORANGE PI
    * O caminho do comando abaixo tem que existir para funcionar, `/home/usuario/Documentos/ORANGEPI/`
~~~shell
sudo dd if=/dev/sdb of=/home/usuario/Documentos/ORANGEPI/orangepi_datadodia.img bs=1M
~~~

* RASPBERRY PI
    * O caminho do comando abaixo tem que existir para funcionar, `/home/usuario/Documentos/RASPBERRYPI/`
~~~shell
sudo dd if=/dev/sdb of=/home/usuario/Documentos/RASPBERRYPI/raspberrypi_datadodia.img bs=1M
~~~

## Espaço Insuficiente no Buffer

### Link Microsoft

* [Click Aqui](https://learn.microsoft.com/pt-br/troubleshoot/windows-server/networking/default-dynamic-port-range-tcpip-chang)


### Exibir Intervalo Atual

* Pode ver o intervalo de portas dinâmico num computador com o Windows Vista ou o Windows Server 2008 através dos seguintes netsh comandos:

~~~shell
netsh int ipv4 show dynamicport tcp
netsh int ipv4 show dynamicport udp
netsh int ipv6 show dynamicport tcp
netsh int ipv6 show dynamicport udp
~~~

### Alterar Intervalo Atual

* Seguem-se comandos de exemplo:

~~~shell
netsh int ipv4 set dynamicport tcp start=40000 num=25535
netsh int ipv4 set dynamicport udp start=40000 num=25535
netsh int ipv6 set dynamicport tcp start=40000 num=25535
netsh int ipv6 set dynamicport udp start=40000 num=25535
~~~

* Padrão

~~~shell
netsh int ipv4 set dynamicport tcp start=49152 num=16384
netsh int ipv4 set dynamicport udp start=49152 num=16384
netsh int ipv6 set dynamicport tcp start=49152 num=16384
netsh int ipv6 set dynamicport udp start=49152 num=16384
~~~

## Renovação Licença de Área de Trabalho Remota

* Este procedimento deverá ser executado nos servidores 15, 17, 153 e 154 ou em qualquer servidor que houver a devida necessidade.

* Para executar esse procedimento deve estar logado com o Usuário `Infra` no servidor em que vai ser executado.

* Apertar telcas WIN + R e digitar regedit 
  
 ![Screenshot](img/procedimento-rotinas-infra/renovacao-licenca-conexao-remota/01.jpg)

* Vai abrir dessa forma ou com o caminho já aplicado.
  
 ![Screenshot](img/procedimento-rotinas-infra/renovacao-licenca-conexao-remota/02.jpg)

* Caso não esteja aplicado basta colar o seguinte diretório `Computador\HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\RCM\GracePeriod` 

 ![Screenshot](img/procedimento-rotinas-infra/renovacao-licenca-conexao-remota/03.jpg)

* Apagar somente o arquivo L$RTMTIMEBOMB 
  
 ![Screenshot](img/procedimento-rotinas-infra/renovacao-licenca-conexao-remota/04.jpg)   

* Clicar em sim e logo após reiniciar o Servidor.
  
 ![Screenshot](img/procedimento-rotinas-infra/renovacao-licenca-conexao-remota/05.jpg)
