# Procedimento Para Exportar Log IIS

## Copiar Log

* Acessar servidor de web service;
* Abrir o IIS;
* Clicar como ilustrado na imagem até a opção Logging click duas vezes;

  ![Screenshot](img/procedimento-log-iis/log_iis_01.jpg)

* Em `Directory` selecione a linha toda e copie como na imagem abaixo em destaque;
* Execute o executar, cole o caminho e pressione `ENTER`;

  ![Screenshot](img/procedimento-log-iis/log_iis_02.jpg)

* Conforme a imagem abaixo, vá clicando na pasta `W3SVC1` até chegar nos arquivos de `LOG`;

  ![Screenshot](img/procedimento-log-iis/log_iis_03.jpg)

* Chegando na pasta com os arquivos de `LOG`, organize pela data mais recente;
* Geralmente copiamos o arquivo de data do dia anterior, porque o log está completo;
* Caso copie o arquivo de log do dia atual ele vai conter apenas os dados até a hora da copia.

  ![Screenshot](img/procedimento-log-iis/log_iis_04.jpg)

* Click com o direito e em copiar o arquivo;

  ![Screenshot](img/procedimento-log-iis/log_iis_05.jpg)

* Abra o executar do windows e acesse o caminho abaixo;

~~~shell
\\192.168.0.1\c$\Users\infra\Desktop
~~~

* Cole o arquivo na pasta aberta;

  ![Screenshot](img/procedimento-log-iis/log_iis_06.jpg)

* Arquivo colado na pasta;

  ![Screenshot](img/procedimento-log-iis/log_iis_07.jpg)

## Importando o log no servidor linux
* Acesse o servidor `192.168.0.1`
* Na área de trabalho encontre o arquivo copiado;

  ![Screenshot](img/procedimento-log-iis/log_iis_08.jpg)

* Renomear o arquivo para `log.log`;

  ![Screenshot](img/procedimento-log-iis/log_iis_09.jpg)

* No servidor `192.168.0.1` Click no icone do software `Bitvise SSH` conforme imagem abaixo;
* Os dados para acesso devem estar como os em destaque;
* Click em Login;

  ![Screenshot](img/procedimento-log-iis/log_iis_10.jpg)

* Na próxima janela informe a senha de acesso;
* Caso não saiba solite alguém ou veja no gerenciador de senhas;

  ![Screenshot](img/procedimento-log-iis/log_iis_11.jpg)

* Click no icone do software e depois na janela de `SFTP`;
* Click duas vezes na pasta `log_iis`;

  ![Screenshot](img/procedimento-log-iis/log_iis_12.jpg)

* Na próxima janela click duas vezes na pasta `files_export_mysql`;

  ![Screenshot](img/procedimento-log-iis/log_iis_13.jpg)

* Em Local files copie o arquivo `log.log` para a pasta files_export_mysql;
* Click com o direito do mouse no arquivo e depois em upload;

  ![Screenshot](img/procedimento-log-iis/log_iis_14.jpg)

* Após a cópia finalizada, vamos acessar o terminal;

  ![Screenshot](img/procedimento-log-iis/log_iis_15.jpg)

## Executando o processo de tratamento do relatório
* Deve-se conectar no software bitvise conforme passo anterior [Click aqui](#importando-o-log-no-servidor-linux)
* Click no icone da barra de ferramentas como imagem abaixo;
* No terminal digite o comando;
~~~shell
sudo su
~~~

  ![Screenshot](img/procedimento-log-iis/log_iis_16.jpg)

* Informe a senha, mesma utilizada para acessar via ssh;

  ![Screenshot](img/procedimento-log-iis/log_iis_17.jpg)

* Execute o comando
~~~shell
cd logs_iis
~~~
* Execute o executar, cole o caminho e pressione `ENTER`;

  ![Screenshot](img/procedimento-log-iis/log_iis_18.jpg)

* Dentro da pasta `log_iis` vamos executar o comando abaixo;
~~~shell
./comandos.sh
~~~

  ![Screenshot](img/procedimento-log-iis/log_iis_19.jpg)

* Será exibida a tela abaixo e selecionar a opção que deseja para extrair o relatório;

  ![Screenshot](img/procedimento-log-iis/log_iis_20.jpg)

* Como exemplo selecionei a opção 10 e pressionei `ENTER`;

  ![Screenshot](img/procedimento-log-iis/log_iis_21.jpg)

* Em 2min o processamento vai ficar alto;
* Agora é só aguardar finalizar o script;
* Quando o processamento normalizar perto dos 10% o script vai estar concluido.

  ![Screenshot](img/procedimento-log-iis/log_iis_22.jpg)

* Quando o processamento normalizar perto dos 10% o script vai estar concluido.

  ![Screenshot](img/procedimento-log-iis/log_iis_23.jpg)

### Visualizando o relatório em um PowerBI
* Após o passo anterior conseguimos abrir o PowerBi criado e visualizarmos os dados.

* Acesse o computador que contenha o powerbi instalado e com acesso ao banco de dados onde foi importado os dados do log.

* Abra o arquivo PowerBI

  ![Screenshot](img/procedimento-log-iis/powerbi_01.jpg)


* Com o arquivo aberto click em Atualizar e aguarde o processo finalizar

  ![Screenshot](img/procedimento-log-iis/powerbi_02.jpg)


* Aqui já conseguimos visualizar as requisições referente a data do log que geramos
  * Podemos filtrar:
    * Pela API que desejamos;
    * Por data, caso tenha datas anteriores conseguimos visualizar aqui;
    * Por cliente.
  
  * Temos um gráfico pizza que nos ilustra a api de maior consumo;
  * Temos grafico por data e conseguimos visualizar os dias de maior consumo;
  * Top 5 das maiores apis e clientes

  ![Screenshot](img/procedimento-log-iis/powerbi_03.jpg)


* Nas demais abas temos mais gráficos com refinamentos para cada uma;
  * Na aba Top 10 Clientes, lista os 10 clientes com maior consumo;
     ![Screenshot](img/procedimento-log-iis/powerbi_04.jpg)
  * Na aba total por metodo, conseguimos selecionar a api e listar os metodos que tem os maiores consumos;
     ![Screenshot](img/procedimento-log-iis/powerbi_05.jpg)
  * Na aba total por api temos um apanhado do total de consumo total de cada uma;
     ![Screenshot](img/procedimento-log-iis/powerbi_06.jpg)
  * Na aba Top 10 Apis, temos as 10 apis mais utilizadas;
     ![Screenshot](img/procedimento-log-iis/powerbi_07.jpg)
  * Na aba Cosumo Api por Metodo, refinamos o consumo por metodo de cada API.
     ![Screenshot](img/procedimento-log-iis/powerbi_08.jpg)
