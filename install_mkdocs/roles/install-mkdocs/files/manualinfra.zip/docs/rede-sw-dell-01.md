# Rede Switch DELL N2048 DOMAIN-150

* Switch 1 core da infra estrutura.

## VLANs

* Para mais detalhes. [Click aqui](vlans.md).

## PORTAS SWITCH

```mermaid
graph TD

0[fa:fa-exchange SWITCH <br/> DELL N2048 <br/> fa:fa-server 192.168.0.1 <br/>  fa:fa-sitemap 10/100/1000/10000 <br/> fa:fa-sitemap DOMAIN-150] 

0 --- 1( fa:fa-sitemap PORTA 1 <br/> fa:fa-server 192.168.0.112 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap ACCESS MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 400 <br/> fa:fa-sitemap RACK02 PP2P19 <br/> fa:fa-sitemap RACK03 PP4P19)

1 --- 2( fa:fa-sitemap PORTA 2 <br/> fa:fa-server Disponivel <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,400 <br/> fa:fa-sitemap RACK04 PP1P04 <br/> fa:fa-sitemap RACK03 PP6P04)

2 --- 3( fa:fa-sitemap PORTA 3 <br/> fa:fa-server 10.0.0.29 <br/> fa:fa-sitemap <br/> ONP02 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,200,300,400,500-505,600-601,700 <br/> fa:fa-sitemap RACK02 PP2P03 <br/> fa:fa-sitemap RACK03 PP4P03)

3 --- 4( fa:fa-sitemap PORTA 4 <br/> fa:fa-server 10.0.0.29 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,200,300,400,500-505,600-601,700 <br/> fa:fa-sitemap RACK02 PP2P02 <br/> fa:fa-sitemap RACK03 PP4P02)

4 --- 5( fa:fa-sitemap PORTA 5 <br/> fa:fa-server 10.0.0.28 <br/> fa:fa-sitemap <br/> ONP02 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,200,300,400,500-507,600-601,700 <br/> fa:fa-sitemap RACK01 PP1P13 <br/> fa:fa-sitemap RACK03 PP1P13)

5 --- 6( fa:fa-sitemap PORTA 6 <br/> fa:fa-server 10.0.0.28 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,200,300,400,500-507,600-601,700 <br/> fa:fa-sitemap RACK01 PP1P12 <br/> fa:fa-sitemap RACK03 PP1P12)

6 --- 7( fa:fa-sitemap PORTA 7 <br/> fa:fa-server 10.0.0.80 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,400 <br/> fa:fa-sitemap RACK02 PP2P05 <br/> fa:fa-sitemap RACK03 PP4P05)

7 --- 8( fa:fa-sitemap PORTA 8 <br/> fa:fa-server 192.168.0.120 <br/> fa:fa-sitemap <br/> ONP02 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap ACCESS MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 505 <br/> fa:fa-sitemap RACK02 PP2P08 <br/> fa:fa-sitemap RACK03 PP4P08)

8 --- 9( fa:fa-sitemap PORTA 9 <br/> fa:fa-server 192.168.0.30 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap ACCESS MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 400 <br/> fa:fa-sitemap RACK01 PP1P20 <br/> fa:fa-sitemap RACK03 PP1P20)

9 --- 10( fa:fa-sitemap PORTA 10 <br/> fa:fa-server 10.0.0.77 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,400 <br/> fa:fa-sitemap RACK01 PP1P16 <br/> fa:fa-sitemap RACK03 PP1P16)

10 --- 11( fa:fa-sitemap PORTA 11 <br/> fa:fa-server 10.0.0.34 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,400 <br/> fa:fa-sitemap RACK02 PP1P15 <br/> fa:fa-sitemap RACK03 PP3P15)

11 --- 12( fa:fa-sitemap PORTA 12 <br/> fa:fa-server 10.0.0.69 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,400 <br/> fa:fa-sitemap RACK02 PP1P24 <br/> fa:fa-sitemap RACK03 PP3P24)




0 --- 13( fa:fa-sitemap PORTA 13 <br/> fa:fa-server SAUNA <br /> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 400,505,601 <br/> fa:fa-sitemap RACK03 AVULSO SAUNA)

13 --- 14( fa:fa-sitemap PORTA 14 <br/> fa:fa-server 10.0.0.30 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,400,505,601,700 <br/> fa:fa-sitemap RACK02 PP2P12 <br/> fa:fa-sitemap RACK03 PP4P12)

14 --- 15( fa:fa-sitemap PORTA 15 <br/> fa:fa-server 10.0.0.32 <br/> fa:fa-sitemap <br/> ONP03 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,200,300,400,500-505,600-601,700 <br/> fa:fa-sitemap RACK02 PP2P16 <br/> fa:fa-sitemap RACK03 PP4P16)

15 --- 16( fa:fa-sitemap PORTA 16 <br/> fa:fa-server 192.168.0.94 <br/> fa:fa-sitemap <br/> ONP02 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap ACCESS MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 400 <br/> fa:fa-sitemap RACK01 PP1P02 <br/> fa:fa-sitemap RACK03 PP1P02)

16 --- 17( fa:fa-sitemap PORTA 17 <br/> fa:fa-server 10.0.0.32 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,200,300,400,500-505,600-601,700 <br/> fa:fa-sitemap RACK02 PP2P14 <br/> fa:fa-sitemap RACK03 PP4P14)

17 --- 18( fa:fa-sitemap PORTA 18 <br/> fa:fa-server 10.0.0.44 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,400 <br/> fa:fa-sitemap RACK02 PP1P19 <br/> fa:fa-sitemap RACK03 PP3P19)

18 --- 19( fa:fa-sitemap PORTA 19 <br/> fa:fa-server Vazio)

19 --- 20( fa:fa-sitemap PORTA 20 <br/> fa:fa-server Vazio PP6P16 Disponivel)

20 --- 21( fa:fa-sitemap PORTA 21 <br/> fa:fa-server 10.0.0.33 <br/> fa:fa-sitemap <br/> ONP04 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 400,507 <br/> fa:fa-sitemap RACK02 PP2P22 <br/> fa:fa-sitemap RACK03 PP4P22)

21 --- 22( fa:fa-sitemap PORTA 22 <br/> fa:fa-server Vazio PP1P18 Disponivel)

22 --- 23( fa:fa-sitemap PORTA 23 <br/> fa:fa-server 192.168.0.120 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap ACCESS MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 400 <br/> fa:fa-sitemap RACK02 PP2P07 <br/> fa:fa-sitemap RACK03 PP4P07)

23 --- 24( fa:fa-sitemap PORTA 24 <br/> fa:fa-server 192.168.0.94 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap ACCESS MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 400 <br/> fa:fa-sitemap RACK01 PP1P01 <br/> fa:fa-sitemap RACK03 PP1P01)



0 --- 25( fa:fa-sitemap PORTA 25 <br/> fa:fa-server 10.0.0.33 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,400,600-602 <br/> fa:fa-sitemap RACK02 PP2P21 <br/> fa:fa-sitemap RACK03 PP4P21)

25 --- 26( fa:fa-sitemap PORTA 26 <br/> fa:fa-server Vazio PP6P17 Disponivel)

26 --- 27( fa:fa-sitemap PORTA 27 <br/> fa:fa-server Vazio PP3P13 Disponivel)

27 --- 28( fa:fa-sitemap PORTA 28 <br/> fa:fa-server 192.168.0.120 <br/> fa:fa-sitemap <br/> ONP04 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap ACCESS MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 601 <br/> fa:fa-sitemap RACK02 PP2P10 <br/> fa:fa-sitemap RACK03 PP4P10)

28 --- 29( fa:fa-sitemap PORTA 29 <br/> fa:fa-server 10.0.0.35 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,400 <br/> fa:fa-sitemap RACK02 PP1P11 <br/> fa:fa-sitemap RACK03 PP3P11)

29 --- 30( fa:fa-sitemap PORTA 30 <br/> fa:fa-server 10.0.0.45 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,400 <br/> fa:fa-sitemap RACK02 PP1P21 <br/> fa:fa-sitemap RACK03 PP3P21)

30 --- 31( fa:fa-sitemap PORTA 31 <br/> fa:fa-server 10.0.0.37 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,400,505-507,601 <br/> fa:fa-sitemap RACK02 PP1P08 <br/> fa:fa-sitemap RACK03 PP3P08)

31 --- 32( fa:fa-sitemap PORTA 32 <br/> fa:fa-server 10.0.0.75 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,400 <br/> fa:fa-sitemap RACK01 PP1P17 <br/> fa:fa-sitemap RACK03 PP1P17)

32 --- 33( fa:fa-sitemap PORTA 33 <br/> fa:fa-server Vazio)

33 --- 34( fa:fa-sitemap PORTA 34 <br/> fa:fa-server 10.0.0.47 <br/> fa:fa-sitemap <br/> ONP03 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,400 <br/> fa:fa-sitemap RACK02 PP1P04 <br/> fa:fa-sitemap RACK03 PP3P04)

34 --- 35( fa:fa-sitemap PORTA 35 <br/> fa:fa-server Vazio)

35 --- 36( fa:fa-sitemap PORTA 36 <br/> fa:fa-server 10.0.0.39 <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,400 <br/> fa:fa-sitemap RACK02 PP1P22 <br/> fa:fa-sitemap RACK03 PP3P22)



0 --- 37( fa:fa-sitemap PORTA 37 <br/> fa:fa-server SALA INFRA <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap all <br/> fa:fa-sitemap AVULSO SALA INFRA)

37 --- 38( fa:fa-sitemap PORTA 38 <br/> fa:fa-server 192.168.0.120<br/> fa:fa-sitemap <br/> ONP03 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap ACCESS MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 501 <br/> fa:fa-sitemap RACK02 PP2P09 <br/> fa:fa-sitemap RACK03 PP4P09)

38 --- 39( fa:fa-sitemap PORTA 39 <br/> fa:fa-server 10.0.0.37 <br/> fa:fa-sitemap <br/> ONP02 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 400,505-507,601 <br/> fa:fa-sitemap RACK02 PP1P09 <br/> fa:fa-sitemap RACK03 PP3P09)

39 --- 40( fa:fa-sitemap PORTA 40 <br/> fa:fa-server UPLINK SW 0.252 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 200,400,505,601)

40 --- 41( fa:fa-sitemap PORTA 41 <br/> fa:fa-server 10.0.0.32 <br/> fa:fa-sitemap <br/> ONP04 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,200,300,400,500-505,600-601,700 <br/> fa:fa-sitemap RACK02 PP2P17 <br/> fa:fa-sitemap RACK03 PP4P17)

41 --- 42( fa:fa-sitemap PORTA 42 <br/> fa:fa-server 10.0.0.32 <br/> fa:fa-sitemap <br/> ONP02 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,200,300,400,500-505,600-601,700 <br/> fa:fa-sitemap RACK02 PP2P15 <br/> fa:fa-sitemap RACK03 PP4P15)

42 --- 43( fa:fa-sitemap PORTA 43 <br/> fa:fa-server UPLINK ANTIGO CPD <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap ACCESS MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 200 <br/> fa:fa-sitemap AVULSO UPLINK ANTIGO CPD)

43 --- 44( fa:fa-sitemap PORTA 44 <br/> fa:fa-server Vazio PP6P18 Disponivel)

44 --- 45( fa:fa-sitemap PORTA 45 <br/> fa:fa-server INTERNET-VOGEL <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap ACCESS MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 500 <br/> fa:fa-sitemap RACK04 PP3P03 <br/> fa:fa-sitemap RACK03 PP8P03)

45 --- 46( fa:fa-sitemap PORTA 46 <br/> fa:fa-server INTERNET-CENTURY PORTA 01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap ACCESS MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 501 <br/> fa:fa-sitemap RACK04 PP3P04 <br/> fa:fa-sitemap RACK03 PP8P04)

46 --- 47( fa:fa-sitemap PORTA 47 <br/> fa:fa-server INTERNET-GVT <br/> fa:fa-sitemap <br/> ONP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap ACCESS MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 502 <br/> fa:fa-sitemap RACK04 PP3P01 <br/> fa:fa-sitemap RACK03 PP8P01)

47 --- 48( fa:fa-sitemap PORTA 48 <br/> fa:fa-server INTERNET-ALGAR <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap ACCESS MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 504 <br/> fa:fa-sitemap RACK04 PP3P02 <br/> fa:fa-sitemap RACK03 PP8P02)

48 --- 49( fa:fa-sitemap PORTA SFP+ 49 <br/> fa:fa-server 10.0.0.52 <br/> fa:fa-sitemap <br/> SFP01 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap 100,200,300,400,500-510,600-601,700)

49 --- 50( fa:fa-sitemap PORTA SFP+ 50 <br/> fa:fa-server FW01 PORTA X9 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap all <br/> fa:fa-sitemap RACK03 <br/> fa:fa-sitemap RACK03)

50 --- 51( fa:fa-sitemap PORTA STACK 01 51 <br/> fa:fa-server SG02P52 STACK 02 <br/> fa:fa-toggle-on VLAN MODE <br/> fa:fa-sitemap TRUNK MODE <br/> fa:fa-toggle-on MEMBER VLANs <br/> fa:fa-sitemap all <br/> fa:fa-sitemap RACK03 <br/> fa:fa-sitemap RACK03)

51 --- 52( fa:fa-sitemap PORTA STACK 02 52 <br/> fa:fa-server Vazio)

```