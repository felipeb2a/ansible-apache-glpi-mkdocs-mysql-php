# Gerador

## Ligar Gerador

### Ligar Gerador Automatico Via Navegador

* Em caso de queda de energia basta definir o gerador como automatico para que o mesmo possa ligar e alimentar o CPD.
* Siga os passos abaixo.

#### Acessando

* Abrir o navegador firefox como na imagem abaixo.

  ![Screenshot](img/gerador/acesso-01.jpg)

* Click em `Mimic`

  ![Screenshot](img/gerador/01.jpg)

#### Visualizando o modulo

* Visualizaremos o modulo como na imagem abaixo:

  ![Screenshot](img/gerador/02.jpg)

#### Ligando o Gerador

* Click na opção `Auto` opçao 01 em destaque conforme a imagem, será solicitado senha de acesso que se encontra no keepass;
* Mas no acesso pelo servidor já está salvo;
* Para certificar que está selecionado a opção `Auto`, o led em vermelho deve estar aceso;

  ![Screenshot](img/gerador/03.jpg)

#### Gerador Ligado

* Agora acompanhe que o gerador deve ligar, ficando com o status `Running` no visor;
* No passo 3 em destaque o led deve ficar verde e por último no passo 4 deve estar com o led verde ligado;
* Se tudo estiver como na imagem abaixo o gerador já vai estar alimentando nosso CPD.

  ![Screenshot](img/gerador/04.jpg)
